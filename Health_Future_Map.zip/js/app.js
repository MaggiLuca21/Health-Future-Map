// Health Future Map - prototipo. Navigazione con #pagina, nessun server richiesto.
// Flusso: scelta ospedale → persona → sequenza di DNA → analisi → malattie trovate → piano di cura.

const PAGINE = [
  ["home", "Home"], ["banca-dati", "Ospedali e persone"], ["analizza", "Analizza DNA"],
  ["cartella", "Cartella"], ["malattie", "Malattie e DNA"], ["progetto", "Il progetto"],
  ["file-pazienti", "File del sito"]
];

let ultimaAnalisi = null;
let pazienteDaAprireInFile = null;

const VISTE = {
  home: () => `
    <section class="hero-home">
      <div class="hero-copy">
        <span class="soprattitolo"><span class="punto-live"></span> GENETICA · ANALISI DIDATTICA</span>
        <h1>Il DNA, letto con <span>chiarezza.</span></h1>
        <p class="hero-lead">Un percorso semplice per esplorare sequenze genetiche, riconoscere marcatori dimostrativi e consultare le informazioni in un unico spazio.</p>
        <div class="hero-actions">
          <a class="btn" href="#analizza">🧬 Avvia un'analisi</a>
          <a class="btn secondario" href="#banca-dati">Esplora le persone</a>
        </div>
        <div class="hero-trust"><span>✓</span> Analisi eseguita nel browser <span class="separatore">·</span> Nessun invio a un server</div>
      </div>
      <div class="hero-art" aria-hidden="true">
        <div class="orb orb-uno"></div><div class="orb orb-due"></div>
        <div class="dna-card"><div class="dna-emoji">🧬</div><div class="dna-linea"></div><div class="dna-pair"><b>A</b><b>T</b><b>G</b><b>C</b></div><span>SEQUENZA GENETICA</span></div>
        <div class="floating-chip chip-sicurezza">⌁ Dati locali</div>
        <div class="floating-chip chip-analisi">✓ Lettura guidata</div>
      </div>
    </section>
    <section class="stat-grid" aria-label="Panoramica del progetto">
      <article class="stat-card"><span class="stat-icon">🏥</span><div><strong>${OSPEDALI.length}</strong><span>Ospedali in Italia</span></div><small>Archivio territoriale</small></article>
      <article class="stat-card"><span class="stat-icon">👤</span><div><strong>${PAZIENTI.length}</strong><span>Profili fittizi</span></div><small>Profili consultabili</small></article>
      <article class="stat-card"><span class="stat-icon">🧬</span><div><strong>${MALATTIE.length}</strong><span>Schede informative</span></div><small>Malattie e predisposizioni</small></article>
      <article class="stat-card"><span class="stat-icon">🔎</span><div><strong>${Object.keys(FIRME).length}</strong><span>Marcatori demo</span></div><small>Firme dimostrative</small></article>
    </section>
    <section class="home-section">
      <div class="section-heading"><div><span class="soprattitolo">IL PERCORSO</span><h2>Quattro passaggi, senza complicazioni</h2></div><p>Ogni fase è guidata e puoi tornare indietro quando vuoi.</p></div>
      <div class="workflow-grid">
        <article class="workflow-card"><span class="workflow-num">01</span><div class="workflow-icon">🏥</div><h3>Scegli il profilo</h3><p>Seleziona regione, ospedale e paziente nell'archivio.</p></article>
        <article class="workflow-card"><span class="workflow-num">02</span><div class="workflow-icon">📄</div><h3>Carica il DNA</h3><p>Incolla una sequenza FASTA o usa un esempio.</p></article>
        <article class="workflow-card"><span class="workflow-num">03</span><div class="workflow-icon">🔬</div><h3>Leggi l'esito</h3><p>Consulta marcatori trovati e livello di attenzione.</p></article>
        <article class="workflow-card"><span class="workflow-num">04</span><div class="workflow-icon">📑</div><h3>Esporta il report</h3><p>Genera il PDF e archivialo nella cartella del paziente.</p></article>
      </div>
    </section>
    <section class="info-banner"><span class="info-banner-icon">ⓘ</span><div><strong>Un supporto didattico, non una diagnosi</strong><p>Le firme genetiche di questo prototipo sono dimostrative. Ogni risultato richiede verifica con test clinici e valutazione di uno specialista.</p></div><a href="#progetto">Scopri i limiti del progetto →</a></section>`,

  "banca-dati": () => {
    setTimeout(() => selettoreOspedalePaziente("selettore", () => location.hash = "#cartella", "Apri cartella"), 0);
    return `<div class="page-heading"><span class="soprattitolo">ARCHIVIO TERRITORIALE</span><h1>Ospedali e persone</h1>
      <p class="sotto">${OSPEDALI.length} strutture di riferimento distribuite in tutte le 20 regioni · ${PAZIENTI.length} profili inventati. Cerca per regione, provincia, ospedale o nome.</p></div>
      <section class="panel panel-selector"><div class="panel-intro"><span class="panel-icon">🏥</span><div><h2>Trova una persona</h2><p class="sotto">Filtra per provincia, struttura o nome.</p></div></div><div id="selettore"></div></section>
      ${moduloNuovaPersona()}
      <section class="panel archive-tools no-stampa"><h2>Gestione archivio</h2><p class="sotto">Puoi esportare una copia locale o importare un archivio già salvato.</p>${bottoniArchivio()}</section>
      <section class="panel archive-tools"><h2>📁 Cartelle e PDF</h2><p class="sotto">Apri l'archivio interno per esplorare le cartelle di tutti i pazienti e i report già esportati.</p><a class="btn secondario" href="#file-pazienti">Apri File del sito</a></section>`;
  },

  analizza: () => {
    const id = Scelta.paziente;
    if (!persona(id)) {
      setTimeout(() => selettoreOspedalePaziente("selettore", () => mostra()), 0);
      return `<div class="page-heading"><span class="soprattitolo">PERCORSO GUIDATO · FASE 1</span><h1>Analizza DNA</h1><p class="sotto">Prima scegli il profilo, poi carica la sequenza da esaminare.</p></div>${passi(1)}<section class="panel panel-selector"><div class="panel-intro"><span class="panel-icon">🏥</span><div><h2>Seleziona una persona</h2><p class="sotto">Scegli la struttura e il profilo a cui associare l'analisi.</p></div></div><div id="selettore"></div></section>`;
    }
    return `<div class="page-heading"><span class="soprattitolo">PERCORSO GUIDATO · FASE 2</span><h1>Analizza DNA</h1><p class="sotto">Carica una sequenza, avvia la lettura e consulta un riepilogo chiaro.</p></div>${passi(ultimaAnalisi ? 3 : 2)}
      ${riquadroPaziente(id)}
      <section class="panel analysis-input-card no-stampa">
        <div class="panel-intro"><span class="panel-icon">🧬</span><div><h2>Inserisci la sequenza</h2><p class="sotto">Puoi incollare il testo FASTA, caricare un file oppure provare un esempio già pronto.</p></div></div>
        <div class="privacy-note"><span>🔒</span><span><strong>Elaborazione locale</strong><br>La sequenza viene analizzata direttamente in questo browser e non viene inviata a un server.</span></div>
        <div class="campo"><label for="fasta">Sequenza DNA (formato FASTA)</label><textarea id="fasta" rows="8" class="mono" placeholder=">nome sequenza&#10;ATGC...">${ultimaAnalisi ? esc(ultimaAnalisi.testo) : ""}</textarea><small class="sotto">Sono riconosciute le basi A, C, G e T. Le basi N vengono considerate non note.</small></div>
        <div class="analysis-actions">
          <button class="btn" onclick="eseguiAnalisi()">🔎 Analizza sequenza</button>
          <label class="btn secondario upload-btn">↑ Carica file FASTA<input type="file" accept=".fasta,.fa,.txt" hidden onchange="caricaFile(this)"></label>
          <label class="select-example"><span>Oppure prova un esempio</span><select aria-label="Scegli una sequenza di esempio" onchange="if(this.value){document.getElementById('fasta').value=sequenzaEsempio(this.value);eseguiAnalisi();this.value=''}">
            <option value="">Seleziona un marcatore…</option>
            ${Object.keys(FIRME).map(m => `<option value="${esc(m)}">${esc(m)}</option>`).join("")}
          </select></label>
        </div>
      </section>
      <div id="risultato" aria-live="polite"></div>`;
  },

  cartella: () => {
    const id = Scelta.paziente;
    if (!persona(id)) {
      setTimeout(() => selettoreOspedalePaziente("selettore", () => mostra()), 0);
      return `<div class="page-heading"><span class="soprattitolo">SCHEDA PERSONALE</span><h1>Cartella</h1><p class="sotto">Scegli l'ospedale e la persona da consultare.</p></div><section class="panel panel-selector"><div id="selettore"></div></section>`;
    }
    const r = Archivio.leggi(id);
    const p = persona(id);
    const malattiePersona = p?.malattie || [];
    const malattieTotali = [...new Set([...malattiePersona, ...r.malattie])];
    return `<div class="page-heading"><span class="soprattitolo">PROFILO PERSONALE</span><h1>Cartella</h1><p class="sotto">Riepilogo delle informazioni e delle analisi registrate.</p></div>${riquadroPaziente(id)}<p class="no-stampa change-person"><a href="#banca-dati">← Cambia persona</a></p>
      <div class="scheda"><h3>Malattie</h3>
        <p>${malattieTotali.length ? [
          ...malattiePersona.map((m, i) => `<span class="etichetta">${esc(m)} <a href="#" onclick="togliMalattiaBanca(${i});return false" title="Togli">×</a></span>`),
          ...r.malattie.map((m, i) => `<span class="etichetta">${esc(m)} <a href="#" onclick="togliMalattia(${i});return false" title="Togli">×</a></span>`)
        ].join("") : '<span class="sotto">Nessuna malattia inserita</span>'}</p>
        <form class="no-stampa" onsubmit="aggiungiMalattia(event)" style="display:flex;gap:6px">
          <input name="m" list="elenco-malattie" placeholder="Aggiungi una malattia" required style="flex:1">
          <datalist id="elenco-malattie">${MALATTIE.map(m => `<option value="${esc(m.nome)}">`).join("")}</datalist>
          <button class="btn piccolo">Aggiungi</button>
        </form></div>
      ${malattieTotali.filter(n => MALATTIE.some(m => m.nome === n)).length ? `<h2>Piano di cura</h2>${pianiDiCura(malattieTotali.map(n => MALATTIE.find(m => m.nome === n)).filter(Boolean))}` : ""}
      <h2>Analisi del DNA</h2>
      ${r.analisi.length ? `<div class="tabella-scroll"><table>
        <tr><th>Data</th><th>Sequenza</th><th>Lunghezza</th><th>Marcatori trovati</th><th>Esito</th></tr>
        ${r.analisi.map(a => { const e = LIVELLI_ESITO[a.livelloEsito]; return `<tr><td>${dataIt(a.data)}</td><td>${esc(a.nome)}</td><td>${a.lunghezza} bp</td>
          <td>${a.marcatori.length ? a.marcatori.map(m => `<span class="etichetta">${esc(m)}</span>`).join("") : "nessuno"}</td>
          <td>${e ? `<span class="status-tag tone-${e.classe}">${e.emoji} ${a.livelloEsito}</span>` : `<span class="sotto">non disponibile</span>`}</td></tr>`; }).join("")}
      </table></div>` : `<p>Nessuna analisi. <a href="#analizza">Analizza il DNA</a>.</p>`}
      <div class="blocco no-stampa"><button class="btn secondario" onclick="esportaCartellaPDF()">⇩ Esporta PDF della cartella</button><p id="cartella-export-status" class="export-status" role="status" aria-live="polite"></p></div>`;
  },

  malattie: () => `
    <div class="page-heading"><span class="soprattitolo">GUIDA INFORMATIVA</span><h1>Malattie e DNA</h1>
    <p class="sotto">Esplora le schede, cerca un gene o filtra per gruppo. Le informazioni sono divulgative e non sostituiscono una valutazione clinica.</p></div>
    <section class="panel disease-filters"><div class="campo"><label for="cerca">Cerca per nome, gene o marcatore</label><input id="cerca" placeholder="Es. HLA-B27, CFTR…" oninput="filtraMalattie()"></div>
    <div class="campo"><label for="gruppo">Filtra per gruppo</label><select id="gruppo" onchange="filtraMalattie()">
      <option value="">Tutti i gruppi</option>
      ${Object.entries(GRUPPI).map(([k, g]) => `<option value="${k}">${g.nome}</option>`).join("")}
    </select></div></section>
    <div id="elenco" class="griglia"></div>`,

  progetto: () => `
    <div class="page-heading"><span class="soprattitolo">INFORMAZIONI</span><h1>Il progetto</h1><p class="sotto">Obiettivi, funzionamento e limiti del prototipo Health Future Map.</p></div>
    <p>Health Future Map (Idea 3): partendo dal DNA si individuano le predisposizioni e le malattie genetiche di una persona e si propone il percorso di cura.</p>
    <section class="panel project-panel"><h2>Come funziona il percorso</h2>
    <p class="sotto project-steps-intro">Dall'analisi iniziale a un possibile monitoraggio nel tempo: ecco le sei fasi previste dal progetto.</p>
    <ol class="project-steps">
      <li><span class="project-step-index">01</span><div class="project-step-content"><h3>Selezione del contesto</h3><p>Si sceglie l'ospedale e si identifica la persona a cui associare l'analisi.</p></div></li>
      <li><span class="project-step-index">02</span><div class="project-step-content"><h3>Caricamento del DNA</h3><p>Si carica la sequenza genetica nel formato FASTA previsto dal prototipo.</p></div></li>
      <li><span class="project-step-index">03</span><div class="project-step-content"><h3>Analisi della sequenza</h3><p>Il sistema calcola alcune caratteristiche della sequenza e cerca i marcatori inclusi nella banca dati dimostrativa.</p></div></li>
      <li><span class="project-step-index">04</span><div class="project-step-content"><h3>Informazioni e approfondimenti</h3><p>Per ogni associazione trovata viene proposta una scheda informativa con lo specialista e gli eventuali esami di conferma da discutere con il medico.</p></div></li>
      <li><span class="project-step-index">05</span><div class="project-step-content"><h3>Archiviazione ed esportazione</h3><p>Il risultato può essere salvato nella cartella della persona ed esportato in PDF.</p></div></li>
      <li class="project-step-future"><span class="project-step-index">06</span><div class="project-step-content"><div class="project-step-title-row"><h3>App collegata a un cerotto intelligente</h3><span class="project-step-tag">Sviluppo futuro</span></div><p>In una possibile evoluzione, un cerotto intelligente potrebbe comunicare con un'app sullo smartphone e raccogliere, in base ai sensori disponibili e alla condizione da monitorare, alcuni parametri nel tempo. L'app mostrerebbe l'andamento con grafici semplici, permetterebbe di annotare sintomi o cambiamenti e potrebbe inviare notifiche quando vengono superate soglie definite insieme al personale sanitario. Con il consenso del paziente, i dati potrebbero essere condivisi con i professionisti che lo seguono.</p><p class="project-step-note">Il cerotto e l'app sono una proposta progettuale, non una funzione già presente nel prototipo. I parametri misurabili e gli eventuali avvisi dovranno essere validati clinicamente; il sistema non sostituirà visite o valutazioni mediche.</p></div></li>
    </ol></section>
    <section class="panel project-panel"><h2>Il semaforo dei risultati</h2><p class="sotto">Il colore è un indicatore di attenzione usato dal prototipo, non una stima clinica della probabilità o della prognosi.</p>
      <div class="legend-grid project-legend">
        <div class="legend-item tone-verde"><span>😊</span><div><b>Verde · Regolare</b><small>Nessuna firma dimostrativa riconosciuta.</small></div></div>
        <div class="legend-item tone-arancione"><span>😐</span><div><b>Arancione · Da approfondire</b><small>Associazione/predisposizione o sequenza incompleta.</small></div></div>
        <div class="legend-item tone-rosso"><span>🙁</span><div><b>Rosso · Attenzione elevata</b><small>Marcatore demo associato a condizioni che richiedono particolare verifica.</small></div></div>
        <div class="legend-item tone-viola"><span>😭</span><div><b>Viola · Critico</b><small>Disponibile solo con un dato critico esplicitamente validato. Non è attivato dalle firme demo attuali.</small></div></div>
      </div>
    </section>
    <section class="panel project-panel"><h2>Etica e privacy</h2>
    <ul>
      <li>Dati genetici e sanitari: consenso, valutazione d'impatto (DPIA), dati identificativi separati (GDPR).</li>
      <li>Ogni risultato genetico va confermato con un test clinico e discusso con un genetista.</li>
      <li>Se dà indicazioni cliniche è un dispositivo medico software (MDR) e un'IA ad alto rischio (AI Act).</li>
    </ul></section>
    <section class="panel project-panel"><h2>Limiti del prototipo</h2>
    <p>I marcatori vengono riconosciuti da firme di DNA dimostrative, generate artificialmente. Non sono varianti cliniche reali e non permettono di calcolare la probabilità che una persona abbia una malattia. Nella versione vera andrebbero sostituite con varianti curate e interpretate secondo fonti cliniche affidabili (per esempio ClinVar e gnomAD). Le malattie complesse dipendono da molte varianti e da fattori ambientali: non si riconoscono da un singolo marcatore.</p></section>`,

  "file-pazienti": () => {
    setTimeout(renderFilePazienti, 0);
    return `<div class="page-heading"><span class="soprattitolo">ARCHIVIO INTERNO</span><h1>File del sito</h1>
      <p class="sotto">Esplora la struttura “Cartelle pazienti”, organizzata per regione, ospedale e paziente. Con il consenso iniziale, la stessa gerarchia è presente anche come cartelle sul dispositivo e i report PDF vengono copiati automaticamente nella sessione corretta.</p><p class="file-sample-note">L'archivio include strutture di riferimento e non costituisce l'elenco ufficiale completo di ogni presidio italiano.</p></div>
      <section class="panel file-manager-panel">
        <div class="file-manager-head"><div><h2>📁 Cartelle pazienti</h2><p class="sotto">${OSPEDALI.length} strutture · ${PAZIENTI.length} cartelle paziente disponibili</p></div><span class="file-manager-count" id="file-manager-count">Caricamento archivio…</span></div>
        <div class="file-manager-notice"><strong>Archivio interno del browser</strong><p>Questa è una cartella virtuale persistente del sito: i PDF sono memorizzati localmente e non viene aperta la finestra “Salva con nome”. Non è una cartella fisica nella directory che contiene index.html.</p></div>
        <div class="campo file-search"><label for="cerca-file-paziente">Cerca regione, ospedale o paziente</label><input id="cerca-file-paziente" placeholder="Es. Lazio, San Martino, Rossi…" oninput="filtraFilePazienti(this.value)"></div>
        <div id="file-tree" class="file-tree"><p class="sotto">Preparazione dell'albero delle cartelle…</p></div>
      </section>`;
  },

  "specifiche-tecniche": () => {
    if (!ultimaAnalisi) return `<div class="page-heading"><span class="soprattitolo">APPROFONDIMENTO</span><h1>Specifiche tecniche</h1><p class="sotto">Non è presente un'analisi da approfondire. Torna all'analisi DNA per iniziare.</p></div><a class="btn" href="#analizza">Vai ad Analizza DNA</a>`;
    const r = ultimaAnalisi.r;
    return `<div class="page-heading"><span class="soprattitolo">APPROFONDIMENTO · ANALISI CORRENTE</span><h1>Specifiche tecniche</h1><p class="sotto">Parametri calcolati sulla sequenza attualmente analizzata. Il risultato viene conservato tornando alla pagina precedente.</p></div>
      ${riquadroPaziente(Scelta.paziente)}
      <section class="panel project-panel"><h2>Metriche della sequenza</h2><div class="griglia">
        <div class="scheda metric-card"><h3>Lunghezza</h3><p class="grande">${r.lunghezza.toLocaleString("it-IT")} <small>bp</small></p></div>
        <div class="scheda metric-card"><h3>Contenuto GC</h3><p class="grande">${r.gc.toFixed(1)}<small>%</small></p></div>
        <div class="scheda metric-card"><h3>Composizione</h3><p>A: ${r.comp.A} · C: ${r.comp.C} · G: ${r.comp.G} · T: ${r.comp.T}</p></div>
        <div class="scheda metric-card"><h3>ORF più lunga</h3><p>${r.orf ? `posizioni ${r.orf.inizio + 1}–${r.orf.fine} (frame ${r.orf.frame}), ${r.orf.codoni} codoni + stop ${r.orf.stop}` : "nessuna ORF di almeno 30 codoni"}</p></div>
      </div></section>
      <section class="panel project-panel"><h2>Marcatori e siti riconosciuti</h2>
        <p>${r.marcatori.length ? r.marcatori.map(m => `<span class="etichetta">${esc(m.marcatore)} a ${m.posizioni.map(p => p + 1).join(", ")}</span>`).join("") : "Nessun marcatore dimostrativo riconosciuto"}</p>
        <p>${r.siti.map(x => `<span class="etichetta">${esc(x.enzima)} (${esc(x.motivo)}) a ${x.posizioni.map(p => p + 1).join(", ")}</span>`).join("") || "Nessun sito di restrizione rilevato"}</p>
        <p>${r.tata.length ? r.tata.map(p => `<span class="etichetta">TATA box a ${p + 1}</span>`).join("") : "Nessun TATA box rilevato"}</p>
        <details class="sequence-details"><summary>Mostra sequenza evidenziata</summary><div class="scheda mono">${evidenzia(r)}</div></details>
        ${r.proteina ? `<details class="sequence-details"><summary>Mostra proteina tradotta (${r.proteina.length} aa)</summary><div class="scheda mono">${r.proteina}</div></details>` : ""}
      </section>
      <p class="medical-disclaimer">I parametri sono calcoli dimostrativi sulla sequenza caricata: non costituiscono un referto clinico.</p>
      <button class="btn secondario" onclick="tornaDaSpecifiche()">← Torna alla pagina precedente</button>`;
  }
};

function moduloNuovaPersona() {
  const regionePredefinita = ospedale(Scelta.ospedale)?.regione || Scelta.regione || "";
  const strutture = OSPEDALI.filter(o => !regionePredefinita || o.regione === regionePredefinita)
    .sort((a, b) => a.citta.localeCompare(b.citta, "it") || a.nome.localeCompare(b.nome, "it"));
  return `<section class="scheda blocco">
    <h2 style="margin-top:0">Crea una nuova cartella paziente</h2>
    <p class="sotto">Compila i dati dimostrativi e premi “Crea cartella paziente”: il profilo e la sua cartella verranno aggiunti all'archivio.</p>
    <form onsubmit="aggiungiPersonaBanca(event)">
      <div class="griglia" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px">
        <div class="campo"><label>Regione</label>
          <select name="regione" required onchange="aggiornaOspedaliNuovoPaziente(this.value)">
            <option value="">— scegli la regione —</option>
            ${REGIONI_ITALIANE.map(r => `<option value="${esc(r)}" ${r === regionePredefinita ? "selected" : ""}>${esc(r)}</option>`).join("")}
          </select>
        </div>
        <div class="campo"><label>Ospedale</label>
          <select name="ospedale" required ${regionePredefinita ? "" : "disabled"}>
            <option value="">— scegli l'ospedale —</option>
            ${strutture.map(o => `<option value="${o.id}" ${o.id === Scelta.ospedale ? "selected" : ""}>${esc(o.citta)} · ${esc(o.nome)}</option>`).join("")}
          </select>
        </div>
        <div class="campo"><label>Nome</label><input name="nome" type="text" maxlength="80" autocomplete="given-name" required></div>
        <div class="campo"><label>Cognome</label><input name="cognome" type="text" maxlength="80" autocomplete="family-name" required></div>
        <div class="campo"><label>Sesso</label>
          <select name="sesso" required><option value="">— seleziona —</option><option value="M">M</option><option value="F">F</option></select>
        </div>
        <div class="campo"><label>Data di nascita</label><input name="nascita" type="date" required></div>
        <div class="campo"><label>Gruppo sanguigno</label>
          <select name="gruppo_sanguigno" required>
            <option value="">— seleziona —</option>
            ${["0+", "0-", "A+", "A-", "B+", "B-", "AB+", "AB-"].map(g => `<option value="${g}">${g}</option>`).join("")}
          </select>
        </div>
        <div class="campo" style="grid-column:1/-1"><label>Malattie già note</label>
          <textarea name="malattie" rows="2" placeholder="Inserisci le malattie separate da virgola; lascia vuoto se non ce ne sono"></textarea>
          <small class="sotto">Come nelle altre schede, il campo può essere vuoto.</small>
        </div>
      </div>
      <p class="sotto" style="font-size:.85rem">Usa esclusivamente dati inventati: il prototipo non è un archivio clinico protetto.</p>
      <button class="btn" type="submit">📁 Crea cartella paziente</button>
      <p id="esito-nuova-persona" role="status" aria-live="polite"></p>
    </form>
  </section>`;
}

function aggiornaOspedaliNuovoPaziente(regione) {
  const selezione = document.querySelector('form select[name="ospedale"]');
  if (!selezione) return;
  const strutture = OSPEDALI.filter(o => o.regione === regione)
    .sort((a, b) => a.citta.localeCompare(b.citta, "it") || a.nome.localeCompare(b.nome, "it"));
  selezione.disabled = !regione;
  selezione.innerHTML = `<option value="">— scegli l'ospedale —</option>` +
    strutture.map(o => `<option value="${o.id}">${esc(o.citta)} · ${esc(o.nome)}</option>`).join("");
}

function aggiungiPersonaBanca(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const dati = new FormData(form);
  const idOspedale = String(dati.get("ospedale") || "");
  const regione = String(dati.get("regione") || "");
  const nome = String(dati.get("nome") || "").trim();
  const cognome = String(dati.get("cognome") || "").trim();
  const sesso = String(dati.get("sesso") || "");
  const nascita = String(dati.get("nascita") || "");
  const gruppo = String(dati.get("gruppo_sanguigno") || "");
  const malattie = String(dati.get("malattie") || "").split(/[,;\n]/).map(m => m.trim()).filter(Boolean);

  if (!ospedale(idOspedale) || ospedale(idOspedale).regione !== regione || !nome || !cognome || !["M", "F"].includes(sesso) ||
      !["0+", "0-", "A+", "A-", "B+", "B-", "AB+", "AB-"].includes(gruppo) || !nascita) {
    alert("Compila correttamente tutti i campi obbligatori.");
    return;
  }
  const dataNascita = new Date(nascita + "T00:00:00");
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  if (Number.isNaN(dataNascita.getTime()) || dataNascita > oggi) {
    alert("Inserisci una data di nascita valida, non futura.");
    return;
  }

  const nuovo = {
    id: prossimoIdPaziente(idOspedale),
    ospedale: idOspedale,
    nome,
    cognome,
    sesso,
    nascita,
    gruppo_sanguigno: gruppo,
    malattie
  };
  try {
    salvaPazienteAggiunto(nuovo);
  } catch (errore) {
    alert(errore.message || "Non è stato possibile aggiungere la persona.");
    return;
  }

  Scelta.regione = regione;
  Scelta.provincia = ospedale(idOspedale).provincia;
  Scelta.ospedale = idOspedale;
  Scelta.paziente = nuovo.id;
  FilePazienti.creaCartellaPaziente(nuovo.id);
  location.hash = "#cartella";
  const esito = document.getElementById("esito-nuova-persona");
  if (esito) esito.textContent = `Persona aggiunta correttamente con codice ${nuovo.id}. La trovi nell'elenco dell'ospedale selezionato.`;
}

function passi(n) {
  return `<div class="passi no-stampa" aria-label="Avanzamento analisi">${["1 · Profilo", "2 · Sequenza DNA", "3 · Esito e report"]
    .map((t, i) => `<span class="${i + 1 < n ? "fatto" : i + 1 === n ? "ora" : ""}"><b>${i + 1 < n ? "✓" : i + 1}</b>${t.slice(3)}</span>`).join("")}</div>`;
}

// Il livello è un indicatore di attenzione del prototipo, NON una diagnosi né una probabilità clinica.
// Il viola è riservato a un livello critico esplicitamente validato e annotato nei dati clinici.
const LIVELLI_ESITO = {
  verde: { emoji: "😊", nome: "Nessun segnale dimostrativo", descrizione: "Non sono state riconosciute firme dimostrative tra quelle presenti nel prototipo. Questo non esclude condizioni o varianti non incluse nella banca dati.", classe: "verde" },
  arancione: { emoji: "😐", nome: "Segnale da approfondire", descrizione: "È emerso un elemento che richiede una verifica: può trattarsi di una predisposizione, di un'associazione o di una sequenza incompleta. Non equivale a una diagnosi.", classe: "arancione" },
  rosso: { emoji: "🙁", nome: "Attenzione elevata", descrizione: "È stato riconosciuto un marcatore dimostrativo associato a una condizione potenzialmente importante. Serve una verifica clinica qualificata: il prototipo non stima la probabilità né la gravità individuale.", classe: "rosso" },
  viola: { emoji: "😭", nome: "Segnale critico da valutare", descrizione: "Livello riservato a un dato clinico esplicitamente validato come critico. Non viene assegnato automaticamente dalle firme dimostrative di questa versione.", classe: "viola" }
};

function valutaEsito(r, malattie) {
  // Il livello viola deve essere scritto nei dati solo dopo revisione clinica.
  if (malattie.some(m => m.livelloEsito === "viola" && m.validazioneClinica === true)) return "viola";
  if (malattie.some(m => m.livelloEsito === "rosso" && m.validazioneClinica === true)) return "rosso";
  if (malattie.some(m => ["monogenica", "immuno"].includes(m.gruppo))) return "rosso";
  if (malattie.length || (r && (r.seq.includes("N") || r.lunghezza < 100))) return "arancione";
  return "verde";
}

function legendaEsiti() {
  return `<section class="legend-box no-stampa"><div class="legend-heading"><h3>Come leggere i colori</h3><span>Indicatore orientativo del prototipo</span></div><div class="legend-grid">
    <div class="legend-item tone-verde"><span>😊</span><div><b>Verde · Regolare</b><small>Nessuna firma demo riconosciuta</small></div></div>
    <div class="legend-item tone-arancione"><span>😐</span><div><b>Arancione · Da approfondire</b><small>Possibile associazione o dato da verificare</small></div></div>
    <div class="legend-item tone-rosso"><span>🙁</span><div><b>Rosso · Attenzione elevata</b><small>Marcatore demo associato a una condizione importante</small></div></div>
    <div class="legend-item tone-viola"><span>😭</span><div><b>Viola · Critico</b><small>Solo con validazione clinica esplicita</small></div></div>
  </div></section>`;
}

// Il piano di cura generato per un elenco di malattie
function pianiDiCura(malattie) {
  return malattie.map(m => {
    const [specialista, esami] = SPECIALISTI[m.nome] || ["Medico di riferimento", "Da definire"];
    const passiCura = m.cura.split(/;|\. /).map(s => s.trim()).filter(Boolean)
      .map(s => s[0].toUpperCase() + s.slice(1));
    return `<div class="scheda" style="margin-bottom:12px">
      <h3>${esc(m.nome)} <span class="etichetta">${esc(m.oggi)}</span></h3>
      <p class="sotto">${esc(GRUPPI[m.gruppo].affidabilita)}</p>
      <p><b>Cosa succede:</b> ${esc(m.corpo)}</p>
      <p><b>Piano di cura proposto:</b></p>
      <ol>${passiCura.map(s => `<li>${esc(s)}</li>`).join("")}</ol>
      <p><b>Specialista:</b> ${esc(specialista)}<br><b>Esami di conferma e controllo:</b> ${esc(esami)}</p>
    </div>`;
  }).join("");
}

function schedaMalattia(m) {
  return `<article class="scheda disease-card">
    <span class="disease-group">${esc(GRUPPI[m.gruppo].nome)}</span><h3>${esc(m.nome)}</h3>
    <p>${m.marcatori.map(x => `<span class="etichetta">${x}</span>`).join("") || `<span class="etichetta">molte varianti</span>`}
       <span class="etichetta">${GRUPPI[m.gruppo].nome}</span></p>
    <p><b>Nel DNA:</b> ${m.dna}<br><b>Nel corpo:</b> ${m.corpo}<br><b>Come si cura:</b> ${m.cura}</p>
    <p><b>Oggi:</b> ${m.oggi}</p>
  </article>`;
}

function filtraMalattie() {
  const q = (document.getElementById("cerca").value || "").toLowerCase();
  const g = document.getElementById("gruppo").value;
  const lista = MALATTIE.filter(m => (!g || m.gruppo === g) &&
    [m.nome, m.dna, ...m.marcatori].join(" ").toLowerCase().includes(q));
  document.getElementById("elenco").innerHTML = lista.map(schedaMalattia).join("") || "<p>Nessun risultato.</p>";
}

function caricaFile(input) {
  const f = input.files[0]; if (!f) return;
  f.text().then(t => { document.getElementById("fasta").value = t; eseguiAnalisi(); });
}

function evidenzia(r) {
  // colora ORF, siti di restrizione, TATA box e marcatori nella sequenza
  const classi = new Array(r.lunghezza).fill("");
  if (r.orf) for (let i = r.orf.inizio; i < r.orf.fine; i++) classi[i] = "orf";
  r.siti.forEach(s => s.posizioni.forEach(p => { for (let i = p; i < p + s.motivo.length; i++) classi[i] = "sito"; }));
  r.tata.forEach(p => { for (let i = p; i < p + 6; i++) classi[i] = "tata"; });
  r.marcatori.forEach(m => m.posizioni.forEach(p => { for (let i = p; i < p + m.firma.length; i++) classi[i] = "marc"; }));
  let html = "", corrente = null;
  for (let i = 0; i < r.lunghezza; i++) {
    if (classi[i] !== corrente) { if (corrente !== null) html += "</span>"; html += `<span class="${classi[i]}">`; corrente = classi[i]; }
    html += r.seq[i];
  }
  return html + "</span>";
}

function eseguiAnalisi() {
  const area = document.getElementById("fasta");
  const testo = area ? area.value : "";
  const r = analizza(testo);
  const out = document.getElementById("risultato");
  if (!out) return;
  if (!r) {
    out.innerHTML = `<div class="result-alert tone-arancione"><span>😐</span><div><strong>Sequenza non leggibile</strong><p>Non sono state trovate basi A, C, G o T. Controlla il file FASTA o incolla una sequenza valida.</p></div></div>`;
    return;
  }
  const trovati = r.marcatori.map(m => m.marcatore);
  const malattie = MALATTIE.filter(m => m.marcatori.some(x => trovati.includes(x)));
  const livello = valutaEsito(r, malattie);
  const esito = LIVELLI_ESITO[livello];
  const basiIgnote = (r.seq.match(/N/g) || []).length;
  const anomaliaTecnica = basesIgnoteLabel(basiIgnote, r.lunghezza);
  ultimaAnalisi = { testo, r, malattie, livello };

  // Salva l'analisi nella cartella della persona.
  Archivio.aggiorna(Scelta.paziente, a => a.analisi.push({
    data: new Date().toISOString().slice(0, 10), nome: r.nome, lunghezza: r.lunghezza,
    marcatori: trovati, livelloEsito: livello
  }));
  const indicatorePassi = document.querySelector(".passi");
  if (indicatorePassi) indicatorePassi.outerHTML = passi(3);

  const dettaglioTecnico = anomaliaTecnica ? `<div class="technical-note"><b>Controllo della sequenza</b><p>${anomaliaTecnica}</p></div>` : "";
  const riepilogoMarcatori = r.marcatori.length
    ? r.marcatori.map(m => `<span class="etichetta">${esc(m.marcatore)} · pos. ${m.posizioni.map(p => p + 1).join(", ")}</span>`).join("")
    : `<span class="sotto">Nessuna firma dimostrativa riconosciuta</span>`;

  out.innerHTML = `
    <section class="result-hero tone-${esito.classe}" id="report-esito">
      <div class="result-emoji" aria-hidden="true">${esito.emoji}</div>
      <div class="result-copy"><span class="result-kicker">ESITO DELL'ANALISI · ${livello.toUpperCase()}</span>
        <h2>${esito.nome}</h2><p>${esito.descrizione}</p>
        <div class="result-meta"><span>📅 ${new Date().toLocaleDateString("it-IT")}</span><span>🧬 ${r.lunghezza.toLocaleString("it-IT")} basi lette</span><span>🔎 ${r.marcatori.length} marcatori riconosciuti</span></div>
      </div>
      <div class="result-actions no-stampa"><button class="btn" onclick="esportaReportPDF()">⇩ Esporta PDF</button><button class="btn secondario" onclick="vaiAlleSpecifiche()">Specifiche tecniche</button></div>
    </section>
    ${dettaglioTecnico}
    <section class="panel result-summary"><div class="panel-intro"><span class="panel-icon">📍</span><div><h3>Riepilogo dei riscontri</h3><p class="sotto">Quello che il sistema ha effettivamente riconosciuto.</p></div></div>
      <div class="summary-grid"><div><span class="summary-label">Marcatori rilevati</span><strong>${r.marcatori.length}</strong></div><div><span class="summary-label">Schede associate</span><strong>${malattie.length}</strong></div><div><span class="summary-label">Lunghezza sequenza</span><strong>${r.lunghezza.toLocaleString("it-IT")} <small>bp</small></strong></div></div>
      <div class="marker-list"><b>Marcatori</b><div>${riepilogoMarcatori}</div></div>
    </section>
    ${malattie.length ? `<section class="home-section matched-section"><div class="section-heading"><div><span class="soprattitolo">ASSOCIAZIONI DEL DATABASE</span><h2>Schede collegate ai marcatori</h2></div><span class="result-count">${malattie.length} ${malattie.length === 1 ? "scheda" : "schede"}</span></div>
      ${pianiDiCura(malattie)}
      <div class="no-stampa result-buttons"><button class="btn" onclick="aggiungiTrovate()">Aggiungi alla cartella</button><button class="btn secondario" onclick="esportaReportPDF()">Esporta piano PDF</button></div>
    </section>` : `<section class="no-match-card"><span>✓</span><div><h3>Nessuna scheda associata</h3><p>La sequenza non contiene le firme dimostrative conosciute da questo prototipo.</p></div></section>`}
    ${legendaEsiti()}
    <section class="home-section technical-section" id="dettagli-analisi"><div class="section-heading"><div><span class="soprattitolo">APPROFONDIMENTO</span><h2>Dettagli della sequenza</h2></div></div>
      <div class="griglia">
        <div class="scheda metric-card"><h3>Lunghezza</h3><p class="grande">${r.lunghezza.toLocaleString("it-IT")} <small>bp</small></p></div>
        <div class="scheda metric-card"><h3>Contenuto GC</h3><p class="grande">${r.gc.toFixed(1)}<small>%</small></p></div>
        <div class="scheda metric-card"><h3>Composizione</h3><p>A: ${r.comp.A} · C: ${r.comp.C} · G: ${r.comp.G} · T: ${r.comp.T}</p></div>
        <div class="scheda metric-card"><h3>ORF più lunga</h3><p>${r.orf ? `posizioni ${r.orf.inizio + 1}–${r.orf.fine} (frame ${r.orf.frame})<br>${r.orf.codoni} codoni + stop ${r.orf.stop}` : "nessuna ORF di almeno 30 codoni"}</p></div>
      </div>
      <p>${r.siti.map(s => `<span class="etichetta">${s.enzima} (${s.motivo}) a ${s.posizioni.map(p => p + 1).join(", ")}</span>`).join("")}
         ${r.tata.length ? `<span class="etichetta">TATA box a ${r.tata.map(p => p + 1).join(", ")}</span>` : ""}</p>
      <p class="sotto"><span class="marc">blu = marcatore</span> · <span class="orf">verde = ORF</span> · <span class="sito">giallo = sito di restrizione</span> · <span class="tata">rosso = TATA box</span></p>
      <details class="sequence-details"><summary>Mostra la sequenza evidenziata</summary><div class="scheda mono">${evidenzia(r)}</div></details>
      ${r.proteina ? `<details class="sequence-details"><summary>Mostra proteina tradotta (${r.proteina.length} aa)</summary><div class="scheda mono">${r.proteina}</div></details>` : ""}
    </section>
    <p class="medical-disclaimer">⚕️ <strong>Nota importante:</strong> questo è un prototipo didattico. Le firme di DNA sono generate a scopo dimostrativo e non rappresentano varianti cliniche validate. Colori e associazioni non indicano diagnosi, probabilità individuali o prognosi. In caso di dubbi, rivolgersi a un genetista o al medico curante.</p>
    <div id="report-export-status" class="export-status" role="status" aria-live="polite"></div>`;

  // Conserva il risultato renderizzato quando si apre la pagina delle specifiche tecniche.
  ultimaAnalisi.html = out.innerHTML;
}

function basesIgnoteLabel(numero, totale) {
  if (numero > 0) return `${numero} basi N su ${totale} indicano posizioni non note: completa o verifica la sequenza prima di interpretare il risultato.`;
  if (totale < 100) return `La sequenza è molto breve (${totale} basi): il risultato potrebbe essere incompleto. Prova con una sequenza FASTA più estesa.`;
  return "";
}

function aggiungiTrovate() {
  Archivio.aggiorna(Scelta.paziente, a => ultimaAnalisi.malattie.forEach(m => a.malattie.includes(m.nome) || a.malattie.push(m.nome)));
  ultimaAnalisi = null;
  location.hash = "#cartella";
}
function aggiungiMalattia(e) {
  e.preventDefault();
  const m = e.target.m.value.trim(); if (!m) return;
  Archivio.aggiorna(Scelta.paziente, r => r.malattie.push(m)); mostra();
}
function togliMalattia(i) { Archivio.aggiorna(Scelta.paziente, r => r.malattie.splice(i, 1)); mostra(); }
function togliMalattiaBanca(i) {
  const p = persona(Scelta.paziente);
  if (!p || !Array.isArray(p.malattie)) return;
  p.malattie.splice(i, 1);
  salvaModifichePaziente(p);
  mostra();
}

function mostra() {
  const id = (location.hash || "#home").slice(1);
  if (!(["analizza", "specifiche-tecniche"].includes(id))) ultimaAnalisi = null;
  document.getElementById("nav").innerHTML = PAGINE
    .map(([k, t]) => `<a href="#${k}" class="${k === id ? "attivo" : ""}">${t}</a>`).join("");
  const p = persona(Scelta.paziente);
  document.getElementById("ruolo").textContent = p ? "Paziente: " + nomeCompleto(p) : "";
  const contenuto = document.getElementById("contenuto");
  const vista = (VISTE[id] || VISTE.home)();
  const specialeTecniche = id === "specifiche-tecniche";
  const pulsante = `<div class="page-top-actions no-stampa"><button type="button" class="btn-riparti" onclick="${specialeTecniche ? "tornaDaSpecifiche()" : "riprendiDallInizio()"}" title="${specialeTecniche ? "Torna all'analisi senza cancellare i dati" : "Azzera il prototipo e torna alla Home"}">↶ Riprendi dall'inizio</button></div>`;
  contenuto.innerHTML = pulsante + vista;
  if (id === "analizza") {
    if (ultimaAnalisi && ultimaAnalisi.html) {
      const out = document.getElementById("risultato");
      if (out) out.innerHTML = ultimaAnalisi.html;
    }
  }
  if (id === "malattie") filtraMalattie();
}

function vaiAlleSpecifiche() { location.hash = "#specifiche-tecniche"; }
function tornaDaSpecifiche() { location.hash = "#analizza"; }

async function riprendiDallInizio() {
  if (!confirm("Vuoi davvero ripartire da zero? Verranno cancellati i pazienti creati, le analisi, i PDF archiviati e le impostazioni grafiche locali.")) return;
  const chiaviMemoria = [
    Archivio.CHIAVE, CHIAVE_PAZIENTI_AGGIUNTI, "hfm_impostazioni_grafiche",
    "health_future_map_file_pazienti_v1", "health_future_map_cartelle_pazienti_v1", "health_future_map_pdf_fallback_v1"
  ];
  chiaviMemoria.forEach(k => Memoria.removeItem(k));
  ["scelta_regione", "scelta_provincia", "scelta_ospedale", "scelta_paziente"].forEach(k => Sessione.removeItem(k));
  ultimaAnalisi = null;
  await FilePazienti.resetta();
  location.hash = "#home";
  location.reload();
}

function apriSchedaDaFile(id) {
  const p = persona(id);
  if (!p) return;
  const o = ospedale(p.ospedale);
  Scelta.regione = o.regione || "";
  Scelta.provincia = o.provincia;
  Scelta.ospedale = o.id;
  Scelta.paziente = p.id;
  location.hash = "#cartella";
}

// Apre l'archivio interno direttamente sulla cartella del paziente appena esportato.
function vaiAiPDFPaziente(id) {
  pazienteDaAprireInFile = String(id || "");
  if (location.hash === "#file-pazienti") mostra();
  else location.hash = "#file-pazienti";
}

function renderFilePazienti() {
  const target = document.getElementById("file-tree");
  if (!target) return;
  const files = FilePazienti.lista();
  const filesPerPaziente = new Map();
  files.forEach(f => {
    if (!filesPerPaziente.has(f.pazienteId)) filesPerPaziente.set(f.pazienteId, []);
    filesPerPaziente.get(f.pazienteId).push(f);
  });
  const pazientiPerOspedale = new Map();
  PAZIENTI.forEach(p => {
    if (!pazientiPerOspedale.has(p.ospedale)) pazientiPerOspedale.set(p.ospedale, []);
    pazientiPerOspedale.get(p.ospedale).push(p);
  });
  const cartelleCreate = new Set(FilePazienti.cartelle().map(c => c.pazienteId));
  const regioniHTML = REGIONI_ITALIANE.map(regione => {
    const strutture = OSPEDALI.filter(o => o.regione === regione)
      .sort((a, b) => a.citta.localeCompare(b.citta, "it") || a.nome.localeCompare(b.nome, "it"));
    const numeroPazienti = strutture.reduce((n, o) => n + (pazientiPerOspedale.get(o.id) || []).length, 0);
    const ospedaliHTML = strutture.map(o => {
      const pazienti = (pazientiPerOspedale.get(o.id) || []).slice().sort((a, b) => nomeCompleto(a).localeCompare(nomeCompleto(b), "it"));
      const pazientiHTML = pazienti.map(p => {
        const report = (filesPerPaziente.get(p.id) || []).slice().sort((a, b) => a.sessione - b.sessione);
        const sessioni = [...new Set(report.map(f => f.sessione))].sort((a, b) => a - b);
        const nomeCartella = `${p.id} - ${nomeCompleto(p)}`;
        return `<div class="file-patient-folder" data-patient-id="${esc(p.id)}" data-folder-search="${esc((nomeCartella + " " + o.nome + " " + regione).toLowerCase())}">
          <div class="file-patient-line"><span class="folder-name">📁 ${esc(nomeCartella)}</span><button type="button" class="file-open-patient" onclick="apriSchedaDaFile('${p.id}')">Apri scheda</button></div>
          ${sessioni.length ? sessioni.map(numero => {
            const dentro = report.filter(f => f.sessione === numero);
            return `<details class="file-session"><summary>📁 Sessione ${String(numero).padStart(3, "0")} <span>${dentro.length} PDF</span></summary>
              ${dentro.map(f => `<div class="file-pdf-row"><span>📄 ${esc(f.filename)}</span><small>${dataIt(f.data)} · ${(f.dimensione / 1024).toFixed(1)} KB</small><div><button type="button" class="file-mini-btn" onclick="FilePazienti.apri('${f.id}')">Apri</button><button type="button" class="file-mini-btn" onclick="FilePazienti.scarica('${f.id}')">Scarica copia</button></div></div>`).join("")}
            </details>`;
          }).join("") : `<div class="file-empty">${cartelleCreate.has(p.id) ? "Cartella creata · nessun PDF esportato" : "Cartella paziente · nessun PDF esportato"}</div>`}
        </div>`;
      }).join("");
      return `<details class="file-folder file-hospital" data-folder-search="${esc((o.nome + " " + o.citta + " " + regione).toLowerCase())}">
        <summary><span>🏥 ${esc(o.nome)}</span><small>${pazienti.length} pazienti · ${esc(o.citta)}</small></summary>
        <div class="file-folder-children">${pazientiHTML || `<p class="file-empty">Nessun paziente presente.</p>`}</div>
      </details>`;
    }).join("");
    const pdfRegione = strutture.reduce((n, o) => n + (pazientiPerOspedale.get(o.id) || []).reduce((m, p) => m + (filesPerPaziente.get(p.id) || []).length, 0), 0);
    return `<details class="file-folder file-region" data-folder-search="${esc(regione.toLowerCase())}">
      <summary><span>🗂️ ${esc(regione)}</span><small>${strutture.length} strutture · ${numeroPazienti} pazienti · ${pdfRegione} PDF</small></summary>
      <div class="file-folder-children">${ospedaliHTML}</div>
    </details>`;
  }).join("");
  document.getElementById("file-manager-count").textContent = `${files.length} PDF archiviati`;
  target.innerHTML = `<div class="file-root"><span>📁</span><strong>Cartelle pazienti</strong><small>${REGIONI_ITALIANE.length} regioni · ${OSPEDALI.length} strutture demo</small></div>${regioniHTML}`;

  // Quando si arriva dal pulsante di esportazione, espande regione, ospedale e ultima sessione.
  if (pazienteDaAprireInFile) {
    const idDaAprire = pazienteDaAprireInFile;
    pazienteDaAprireInFile = null;
    const cartella = [...target.querySelectorAll(".file-patient-folder")]
      .find(nodo => nodo.dataset.patientId === idDaAprire);
    if (cartella) {
      const regione = cartella.closest(".file-region");
      const ospedale = cartella.closest(".file-hospital");
      if (regione) regione.open = true;
      if (ospedale) ospedale.open = true;
      const sessioni = cartella.querySelectorAll(".file-session");
      if (sessioni.length) sessioni[sessioni.length - 1].open = true;
      cartella.classList.add("file-patient-highlight");
      setTimeout(() => {
        cartella.scrollIntoView({ behavior: "smooth", block: "center" });
        setTimeout(() => cartella.classList.remove("file-patient-highlight"), 2200);
      }, 40);
    }
  }
}

function filtraFilePazienti(query) {
  const q = String(query || "").trim().toLowerCase();
  document.querySelectorAll(".file-region, .file-hospital, .file-patient-folder").forEach(nodo => {
    const testo = (nodo.dataset.folderSearch || "") + " " + nodo.textContent.toLowerCase();
    const mostra = !q || testo.includes(q);
    if (nodo.classList.contains("file-patient-folder")) nodo.style.display = mostra ? "" : "none";
    else { nodo.hidden = !mostra; if (q && mostra) nodo.open = true; }
  });
}

function testoPdf(s) {
  return String(s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[’‘]/g, "'").replace(/[–—]/g, "-").replace(/[·•]/g, "-")
    .replace(/[^\x20-\x7E]/g, " ").replace(/\s+/g, " ").trim();
}
function pdfEscape(s) { return testoPdf(s).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)"); }
function creaPdfDaLinee(linee) {
  const righe = [];
  linee.forEach(testo => {
    const x = testoPdf(testo);
    if (!x) { righe.push(""); return; }
    for (let i = 0; i < x.length; i += 88) righe.push(x.slice(i, i + 88));
  });
  const pagine = [];
  for (let i = 0; i < righe.length; i += 48) pagine.push(righe.slice(i, i + 48));
  if (!pagine.length) pagine.push(["Health Future Map"]);
  const oggetti = [];
  const idsPagine = pagine.map((_, i) => 4 + i * 2);
  oggetti[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  oggetti[2] = `<< /Type /Pages /Kids [${idsPagine.map(id => `${id} 0 R`).join(" ")}] /Count ${pagine.length} >>`;
  oggetti[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
  pagine.forEach((pagina, indice) => {
    const pageId = 4 + indice * 2;
    const contentId = pageId + 1;
    let stream = "BT /F1 17 Tf 50 790 Td (HEALTH FUTURE MAP - REPORT DIDATTICO) Tj ET\n";
    pagina.forEach((riga, n) => {
      const y = 760 - n * 14;
      if (riga) stream += `BT /F1 10 Tf 50 ${y} Td (${pdfEscape(riga)}) Tj ET\n`;
    });
    oggetti[pageId] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents ${contentId} 0 R >>`;
    oggetti[contentId] = `<< /Length ${stream.length} >>\nstream\n${stream}endstream`;
  });
  let pdf = "%PDF-1.4\n%HealthFutureMap\n";
  const offset = [0];
  for (let id = 1; id < oggetti.length; id++) {
    offset[id] = pdf.length;
    pdf += `${id} 0 obj\n${oggetti[id]}\nendobj\n`;
  }
  const inizioXref = pdf.length;
  pdf += `xref\n0 ${oggetti.length}\n0000000000 65535 f \n`;
  for (let id = 1; id < oggetti.length; id++) pdf += `${String(offset[id]).padStart(10, "0")} 00000 n \n`;
  pdf += `trailer\n<< /Size ${oggetti.length} /Root 1 0 R >>\nstartxref\n${inizioXref}\n%%EOF`;
  return pdf;
}

async function esportaReportPDF() {
  if (!ultimaAnalisi || !Scelta.paziente) { alert("Prima esegui un'analisi associata a un paziente."); return; }
  const p = persona(Scelta.paziente), o = p && ospedale(p.ospedale);
  if (!p || !o) { alert("Seleziona un paziente valido prima di esportare."); return; }
  const sessione = FilePazienti.prossimaSessione(p.id);
  const r = ultimaAnalisi.r;
  const esito = LIVELLI_ESITO[ultimaAnalisi.livello];
  const marcatori = r.marcatori.length ? r.marcatori.map(m => `${m.marcatore}: posizioni ${m.posizioni.map(x => x + 1).join(", ")}`) : ["Nessuna firma dimostrativa riconosciuta"];
  const associate = ultimaAnalisi.malattie.length ? ultimaAnalisi.malattie.map(m => m.nome) : ["Nessuna scheda associata"];
  const linee = [
    "REPORT PAZIENTE - ARCHIVIO DIDATTICO", "", `Paziente: ${nomeCompleto(p)}`, `Codice paziente: ${p.id}`,
    `Data di nascita: ${dataIt(p.nascita)} - Sesso: ${p.sesso} - Gruppo sanguigno: ${p.gruppo_sanguigno}`,
    `Regione: ${o.regione} - Ospedale: ${o.nome} (${o.citta})`, `Sessione: ${String(sessione).padStart(3, "0")}`,
    `Data esportazione: ${new Date().toLocaleDateString("it-IT")}`, "", "ESITO DELL'ANALISI",
    `Livello: ${ultimaAnalisi.livello.toUpperCase()} - ${esito ? esito.nome : "Non disponibile"}`,
    esito ? esito.descrizione : "", `Sequenza: ${r.nome}`, `Lunghezza: ${r.lunghezza} basi`,
    `Contenuto GC: ${r.gc.toFixed(1)}%`, `Composizione: A ${r.comp.A} - C ${r.comp.C} - G ${r.comp.G} - T ${r.comp.T}`,
    "", "MARCATORI RICONOSCIUTI", ...marcatori, "", "SCHEDE ASSOCIATE", ...associate,
    "", "NOTA IMPORTANTE", "Prototipo scolastico con firme genetiche artificiali e dimostrative.",
    "Questo documento non e' un referto clinico e non esprime una diagnosi o una prognosi.",
    "I dati del paziente e i risultati devono essere considerati esclusivamente fittizi."
  ];
  const bottone = document.querySelectorAll("button[onclick='esportaReportPDF()']");
  bottone.forEach(b => { b.dataset.testoOriginale = b.textContent; b.disabled = true; b.textContent = "Salvataggio…"; });
  try {
    const pdf = creaPdfDaLinee(linee);
    const entry = await FilePazienti.archiviaPDF({ pazienteId: p.id, report: pdf, sessione });
    const status = document.getElementById("report-export-status");
    if (status && window.HFM_STORAGE_MODE !== true) {
      status.innerHTML = `✓ PDF salvato nell'archivio interno del browser. Non sono state create cartelle sul dispositivo.<br><button type="button" class="btn secondario btn-apri-pdf-paziente">Vai ai PDF del paziente</button>`;
      const apriArchivio = status.querySelector(".btn-apri-pdf-paziente");
      if (apriArchivio) apriArchivio.addEventListener("click", () => vaiAiPDFPaziente(p.id), { once: true });
    } else if (status) {
      status.innerHTML = `✓ PDF archiviato automaticamente in <strong>${esc(entry.percorso)}</strong>. <a href="#file-pazienti">Apri File del sito</a>`;
    } else alert(`PDF archiviato in: ${entry.percorso}`);
  } catch (errore) {
    console.error(errore);
    alert("Non è stato possibile archiviare il PDF in questo browser. " + (errore.message || ""));
  } finally {
    bottone.forEach(b => { b.disabled = false; if (b.dataset.testoOriginale) b.textContent = b.dataset.testoOriginale; });
  }
}

async function esportaCartellaPDF() {
  const p = persona(Scelta.paziente);
  const o = p && ospedale(p.ospedale);
  if (!p || !o) { alert("Seleziona un paziente prima di esportare la cartella."); return; }
  const archivio = Archivio.leggi(p.id);
  const sessione = FilePazienti.prossimaSessione(p.id);
  const malattie = [...new Set([...(p.malattie || []), ...(archivio.malattie || [])])];
  const linee = [
    "CARTELLA PAZIENTE - ARCHIVIO DIDATTICO", "", `Paziente: ${nomeCompleto(p)}`, `Codice paziente: ${p.id}`,
    `Data di nascita: ${dataIt(p.nascita)} - Sesso: ${p.sesso} - Gruppo sanguigno: ${p.gruppo_sanguigno}`,
    `Regione: ${o.regione} - Ospedale: ${o.nome} (${o.citta})`, `Sessione: ${String(sessione).padStart(3, "0")}`,
    `Data esportazione: ${new Date().toLocaleDateString("it-IT")}`, "", "MALATTIE REGISTRATE",
    ...(malattie.length ? malattie : ["Nessuna malattia registrata"]), "", "ANALISI DEL DNA",
    ...(archivio.analisi.length ? archivio.analisi.map((a, i) => `${i + 1}. ${a.data} - ${a.nome} - ${a.lunghezza} basi - marcatori: ${(a.marcatori || []).join(", ") || "nessuno"} - esito: ${a.livelloEsito || "non disponibile"}`) : ["Nessuna analisi registrata"]),
    "", "NOTA IMPORTANTE", "Prototipo scolastico: dati e profili sono fittizi.",
    "Questo documento non e' un referto clinico e non esprime una diagnosi o una prognosi."
  ];
  try {
    const entry = await FilePazienti.archiviaPDF({ pazienteId: p.id, report: creaPdfDaLinee(linee), sessione });
    const status = document.getElementById("cartella-export-status");
    if (status) status.innerHTML = `✓ PDF archiviato automaticamente in <strong>${esc(entry.percorso)}</strong>. <a href="#file-pazienti">Apri File del sito</a>`;
  } catch (errore) {
    console.error(errore);
    alert("Non è stato possibile archiviare il PDF. " + (errore.message || ""));
  }
}


addEventListener("hashchange", () => { mostra(); scrollTo(0, 0); });
addEventListener("DOMContentLoaded", mostra);


// Gestione popup Videocall con Dottore
document.addEventListener('DOMContentLoaded', () => {
  const btnVideocall = document.getElementById('btn-videocall');
  const popupVideocall = document.getElementById('popup-videocall');
  const chiudiPopup = document.getElementById('chiudi-popup');

  if (btnVideocall && popupVideocall) {
    btnVideocall.addEventListener('click', () => {
      popupVideocall.style.display = 'flex';
    });
  }

  if (chiudiPopup && popupVideocall) {
    chiudiPopup.addEventListener('click', () => {
      popupVideocall.style.display = 'none';
    });
  }

  const btnCerotto = document.getElementById('btn-cerotto');
  const popupCerotto = document.getElementById('popup-cerotto');
  const chiudiPopupCerotto = document.getElementById('chiudi-popup-cerotto');

  if (btnCerotto && popupCerotto) {
    btnCerotto.addEventListener('click', () => {
      popupCerotto.style.display = 'flex';
    });
  }

  if (chiudiPopupCerotto && popupCerotto) {
    chiudiPopupCerotto.addEventListener('click', () => {
      popupCerotto.style.display = 'none';
    });
  }

  window.addEventListener('click', (event) => {
    if (event.target === popupVideocall) {
      popupVideocall.style.display = 'none';
    }
    if (event.target === popupCerotto) {
      popupCerotto.style.display = 'none';
    }
  });
});


// Gestione Barra a Scorrimento Impostazioni Grafiche (Dark/Light Mode e personalizzazione)
(function initImpostazioniGrafiche() {
  const CHIAVE_STORAGE = 'hfm_impostazioni_grafiche';
  const PREDEFINITI = {
    tema: 'auto',
    colore: 'blu',
    testo: 100,
    font: 'sans',
    raggio: 10,
    contrasto: false
  };

  const PALETTE = {
    viola:    { light: '#6a3fb5', lightBg: '#efe8fa', dark: '#b39ae8', darkBg: '#2a2340' },
    blu:      { light: '#315b78', lightBg: '#eaf2f7', dark: '#8fb8d0', darkBg: '#263b49' },
    verde:    { light: '#0d9488', lightBg: '#ccfbf1', dark: '#2dd4bf', darkBg: '#134e4a' },
    bordeaux: { light: '#be123c', lightBg: '#ffe4e6', dark: '#fb7185', darkBg: '#4c0519' },
    ambra:    { light: '#d97706', lightBg: '#fef3c7', dark: '#fbbf24', darkBg: '#451a03' }
  };

  const FONT_MAP = {
    sans: 'Arial, Helvetica, sans-serif',
    'sans-serif': 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif',
    serif: 'Georgia, "Times New Roman", serif',
    mono: 'ui-monospace, "Cascadia Code", Menlo, Consolas, monospace'
  };

  function caricaImpostazioni() {
    try {
      const salvate = JSON.parse(localStorage.getItem(CHIAVE_STORAGE) || '{}');
      return { ...PREDEFINITI, ...salvate };
    } catch {
      return { ...PREDEFINITI };
    }
  }

  function salvaImpostazioni(cfg) {
    try {
      localStorage.setItem(CHIAVE_STORAGE, JSON.stringify(cfg));
    } catch {}
  }

  function isDarkEffettivo(tema) {
    if (tema === 'dark') return true;
    if (tema === 'light') return false;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  }

  function applicaImpostazioni(cfg) {
    const root = document.documentElement;

    // Tema light / dark / auto
    if (cfg.tema === 'auto') {
      root.removeAttribute('data-tema');
    } else {
      root.setAttribute('data-tema', cfg.tema);
    }

    // Colore primario adattato al tema
    const pal = PALETTE[cfg.colore] || PALETTE.viola;
    const dark = isDarkEffettivo(cfg.tema);
    root.style.setProperty('--primario', dark ? pal.dark : pal.light);
    root.style.setProperty('--primario-chiaro', dark ? pal.darkBg : pal.lightBg);

    // Dimensione testo
    root.style.fontSize = cfg.testo + '%';

    // Font
    root.style.setProperty('--font-principale', FONT_MAP[cfg.font] || FONT_MAP.sans);

    // Arrotondamento
    root.style.setProperty('--raggio', cfg.raggio + 'px');

    // Contrasto
    if (cfg.contrasto) {
      root.setAttribute('data-contrasto', 'alto');
    } else {
      root.removeAttribute('data-contrasto');
    }

    // Sincronizza controlli UI se presenti
    document.querySelectorAll('.tema-btn').forEach(btn => {
      btn.classList.toggle('attivo', btn.dataset.tema === cfg.tema);
    });
    document.querySelectorAll('.colore-btn').forEach(btn => {
      btn.classList.toggle('attivo', btn.dataset.colore === cfg.colore);
    });
    const rangeTesto = document.getElementById('range-testo');
    const valTesto = document.getElementById('val-testo');
    if (rangeTesto && valTesto) {
      rangeTesto.value = cfg.testo;
      valTesto.textContent = cfg.testo + '%';
    }
    const selectFont = document.getElementById('select-font');
    if (selectFont) selectFont.value = cfg.font;

    const rangeRaggio = document.getElementById('range-raggio');
    const valRaggio = document.getElementById('val-raggio');
    if (rangeRaggio && valRaggio) {
      rangeRaggio.value = cfg.raggio;
      valRaggio.textContent = cfg.raggio + 'px';
    }
    const checkContrasto = document.getElementById('check-contrasto');
    if (checkContrasto) checkContrasto.checked = !!cfg.contrasto;
  }

  let cfgCorrente = caricaImpostazioni();
  applicaImpostazioni(cfgCorrente);

  // Ascolta cambi tema del sistema operativo quando è impostato su "auto"
  if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
      if (cfgCorrente.tema === 'auto') applicaImpostazioni(cfgCorrente);
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    applicaImpostazioni(cfgCorrente);

    const btnApri = document.getElementById('btn-impostazioni');
    const btnChiudi = document.getElementById('chiudi-impostazioni');
    const drawer = document.getElementById('barra-impostazioni');
    const overlay = document.getElementById('overlay-impostazioni');

    function apriDrawer() {
      if (!drawer || !overlay) return;
      drawer.classList.add('aperto');
      overlay.classList.add('aperto');
      overlay.setAttribute('aria-hidden', 'false');
    }

    function chiudiDrawer() {
      if (!drawer || !overlay) return;
      drawer.classList.remove('aperto');
      overlay.classList.remove('aperto');
      overlay.setAttribute('aria-hidden', 'true');
    }

    if (btnApri) btnApri.addEventListener('click', apriDrawer);
    if (btnChiudi) btnChiudi.addEventListener('click', chiudiDrawer);
    if (overlay) overlay.addEventListener('click', chiudiDrawer);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') chiudiDrawer();
    });

    document.querySelectorAll('.tema-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        cfgCorrente.tema = btn.dataset.tema;
        salvaImpostazioni(cfgCorrente);
        applicaImpostazioni(cfgCorrente);
      });
    });

    document.querySelectorAll('.colore-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        cfgCorrente.colore = btn.dataset.colore;
        salvaImpostazioni(cfgCorrente);
        applicaImpostazioni(cfgCorrente);
      });
    });

    const rangeTesto = document.getElementById('range-testo');
    if (rangeTesto) {
      rangeTesto.addEventListener('input', () => {
        cfgCorrente.testo = Number(rangeTesto.value);
        salvaImpostazioni(cfgCorrente);
        applicaImpostazioni(cfgCorrente);
      });
    }

    const selectFont = document.getElementById('select-font');
    if (selectFont) {
      selectFont.addEventListener('change', () => {
        cfgCorrente.font = selectFont.value;
        salvaImpostazioni(cfgCorrente);
        applicaImpostazioni(cfgCorrente);
      });
    }

    const rangeRaggio = document.getElementById('range-raggio');
    if (rangeRaggio) {
      rangeRaggio.addEventListener('input', () => {
        cfgCorrente.raggio = Number(rangeRaggio.value);
        salvaImpostazioni(cfgCorrente);
        applicaImpostazioni(cfgCorrente);
      });
    }

    const checkContrasto = document.getElementById('check-contrasto');
    if (checkContrasto) {
      checkContrasto.addEventListener('change', () => {
        cfgCorrente.contrasto = checkContrasto.checked;
        salvaImpostazioni(cfgCorrente);
        applicaImpostazioni(cfgCorrente);
      });
    }

    const btnReset = document.getElementById('reset-impostazioni');
    if (btnReset) {
      btnReset.addEventListener('click', () => {
        cfgCorrente = { ...PREDEFINITI };
        salvaImpostazioni(cfgCorrente);
        applicaImpostazioni(cfgCorrente);
      });
    }
  });
})();
