(() => {
  const overlay = document.getElementById("schermata-consenso");
  const si = document.getElementById("consenso-si");
  const no = document.getElementById("consenso-no");
  const stato = document.getElementById("consenso-stato");
  const avvia = () => { overlay.hidden = true; document.body.classList.remove("in-attesa-consenso"); };
  document.body.classList.add("in-attesa-consenso");
  no.addEventListener("click", () => {
    window.HFM_STORAGE_MODE = false;
    sessionStorage.setItem("hfm_archivio_fisico", "no");
    avvia();
  });
  si.addEventListener("click", async () => {
    si.disabled = true; no.disabled = true;
    stato.textContent = "Preparazione delle cartelle dedicate…";
    try {
      // I dati sono già stati dichiarati dagli script caricati dopo questo file.
      const strutture = typeof OSPEDALI !== "undefined" ? OSPEDALI : [];
      const profili = typeof PAZIENTI !== "undefined" ? PAZIENTI : [];
      const response = await fetch("/api/inizializza", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ospedali: strutture, pazienti: profili })
      });
      if (!response.ok) throw new Error("Server locale non raggiungibile");
      window.HFM_STORAGE_MODE = true;
      sessionStorage.setItem("hfm_archivio_fisico", "si");
      stato.textContent = "Cartelle predisposte. Apertura della piattaforma…";
    } catch (e) {
      window.HFM_STORAGE_MODE = false;
      stato.textContent = "Non è stato possibile attivare le cartelle sul dispositivo. Continuiamo con l'archivio locale del browser.";
      console.warn(e);
    }
    avvia();
  });
})();