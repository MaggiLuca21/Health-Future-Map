// Analisi di base di una sequenza di DNA (filamento 5'→3'), tutta nel browser.

const CODICE_GENETICO = (() => {
  const basi = "TCAG", aa = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG";
  const t = {}; let i = 0;
  for (const a of basi) for (const b of basi) for (const c of basi) t[a + b + c] = aa[i++];
  return t;
})();

const SITI_RESTRIZIONE = { EcoRI: "GAATTC", BamHI: "GGATCC", HindIII: "AAGCTT", NotI: "GCGGCCGC", XhoI: "CTCGAG", PstI: "CTGCAG" };

// Legge FASTA (una o più righe con >) oppure testo semplice.
function leggiFasta(testo) {
  const righe = testo.trim().split(/\r?\n/);
  const nome = righe[0]?.startsWith(">") ? righe.shift().slice(1).trim() : "sequenza senza nome";
  const seq = righe.join("").toUpperCase().replace(/[^ACGTN]/g, "");
  return { nome, seq };
}

function trovaTutte(seq, motivo) {
  const pos = []; let i = seq.indexOf(motivo);
  while (i !== -1) { pos.push(i); i = seq.indexOf(motivo, i + 1); }
  return pos;
}

// ORF più lunga sul filamento diretto, nei tre schemi di lettura.
function orfPiuLunga(seq, minCodoni = 30) {
  let migliore = null;
  for (let frame = 0; frame < 3; frame++) {
    for (let i = frame; i + 3 <= seq.length; i += 3) {
      if (seq.slice(i, i + 3) !== "ATG") continue;
      for (let j = i; j + 3 <= seq.length; j += 3) {
        if (CODICE_GENETICO[seq.slice(j, j + 3)] === "*") {
          const codoni = (j - i) / 3;
          if (codoni >= minCodoni && (!migliore || codoni > migliore.codoni))
            migliore = { inizio: i, fine: j + 3, codoni, frame: frame + 1, stop: seq.slice(j, j + 3) };
          i = j; // l'ORF successiva parte dopo questo stop
          break;
        }
      }
    }
  }
  return migliore;
}

function traduci(seq) {
  let p = "";
  for (let i = 0; i + 3 <= seq.length; i += 3) p += CODICE_GENETICO[seq.slice(i, i + 3)] || "X";
  return p;
}

function analizza(testo) {
  const { nome, seq } = leggiFasta(testo);
  if (!seq) return null;
  const conta = b => (seq.match(new RegExp(b, "g")) || []).length;
  const comp = { A: conta("A"), C: conta("C"), G: conta("G"), T: conta("T") };
  const orf = orfPiuLunga(seq);
  const siti = Object.entries(SITI_RESTRIZIONE)
    .map(([enzima, motivo]) => ({ enzima, motivo, posizioni: trovaTutte(seq, motivo) }))
    .filter(s => s.posizioni.length);
  return {
    nome, seq, lunghezza: seq.length, comp,
    gc: (comp.G + comp.C) / seq.length * 100,
    orf, proteina: orf ? traduci(seq.slice(orf.inizio, orf.fine - 3)) : "",
    siti, tata: trovaTutte(seq, "TATAAT").concat(trovaTutte(seq, "TATAAA")).sort((a, b) => a - b),
    marcatori: cercaMarcatori(seq)
  };
}

// Cerca le firme dei marcatori (js/firme.js) nella sequenza.
function cercaMarcatori(seq) {
  return Object.entries(FIRME)
    .map(([marcatore, firma]) => ({ marcatore, firma, posizioni: trovaTutte(seq, firma) }))
    .filter(m => m.posizioni.length);
}

// Sequenza di prova con la firma di un marcatore in mezzo (stessa idea dei file in esempi/).
function sequenzaEsempio(marcatore) {
  let x = 0;
  for (const c of marcatore) x = (x * 31 + c.charCodeAt(0)) >>> 0;
  const caso = n => Array.from({ length: n }, () => "ACGT"[(x = (x * 1103515245 + 12345) >>> 0) >>> 30]).join("");
  const s = caso(250) + FIRME[marcatore] + caso(250);
  return `>esempio ${marcatore}\n` + s.match(/.{1,60}/g).join("\n");
}
