// Rete dimostrativa nazionale: strutture ospedaliere di riferimento e pazienti interamente inventati.
// Le strutture sono un campione rappresentativo per regione, non un'anagrafe ufficiale completa.
// Per la copertura ufficiale di tutte le strutture attive consultare l'anagrafe del Ministero della Salute.

const REGIONI_ITALIANE = [
  "Abruzzo", "Basilicata", "Calabria", "Campania", "Emilia-Romagna",
  "Friuli-Venezia Giulia", "Lazio", "Liguria", "Lombardia", "Marche",
  "Molise", "Piemonte", "Puglia", "Sardegna", "Sicilia", "Toscana",
  "Trentino-Alto Adige", "Umbria", "Valle d'Aosta", "Veneto"
];

const PROVINCE = {
  AO: "Aosta", AL: "Alessandria", AT: "Asti", BI: "Biella", CN: "Cuneo", NO: "Novara", TO: "Torino", VB: "Verbano-Cusio-Ossola", VC: "Vercelli",
  BG: "Bergamo", BS: "Brescia", CO: "Como", CR: "Cremona", LC: "Lecco", LO: "Lodi", MB: "Monza e Brianza", MI: "Milano", MN: "Mantova", PV: "Pavia", SO: "Sondrio", VA: "Varese",
  BZ: "Bolzano", TN: "Trento",
  BL: "Belluno", PD: "Padova", RO: "Rovigo", TV: "Treviso", VE: "Venezia", VI: "Vicenza", VR: "Verona",
  GO: "Gorizia", PN: "Pordenone", TS: "Trieste", UD: "Udine",
  GE: "Genova", IM: "Imperia", SP: "La Spezia", SV: "Savona",
  BO: "Bologna", FE: "Ferrara", FC: "Forlì-Cesena", MO: "Modena", PC: "Piacenza", PR: "Parma", RA: "Ravenna", RE: "Reggio Emilia", RN: "Rimini",
  AR: "Arezzo", FI: "Firenze", GR: "Grosseto", LI: "Livorno", LU: "Lucca", MS: "Massa-Carrara", PI: "Pisa", PO: "Prato", PT: "Pistoia", SI: "Siena",
  PG: "Perugia", TR: "Terni",
  AN: "Ancona", AP: "Ascoli Piceno", FM: "Fermo", MC: "Macerata", PU: "Pesaro e Urbino",
  FR: "Frosinone", LT: "Latina", RI: "Rieti", RM: "Roma", VT: "Viterbo",
  AQ: "L'Aquila", CH: "Chieti", PE: "Pescara", TE: "Teramo",
  CB: "Campobasso", IS: "Isernia",
  AV: "Avellino", BN: "Benevento", CE: "Caserta", NA: "Napoli", SA: "Salerno",
  MT: "Matera", PZ: "Potenza",
  CZ: "Catanzaro", CS: "Cosenza", KR: "Crotone", RC: "Reggio Calabria", VV: "Vibo Valentia",
  AG: "Agrigento", CL: "Caltanissetta", CT: "Catania", EN: "Enna", ME: "Messina", PA: "Palermo", RG: "Ragusa", SR: "Siracusa", TP: "Trapani",
  CA: "Cagliari", NU: "Nuoro", OR: "Oristano", SS: "Sassari", SU: "Sud Sardegna",
  BA: "Bari", BR: "Brindisi", BT: "Barletta-Andria-Trani", FG: "Foggia", LE: "Lecce", TA: "Taranto"
};

const REGIONE_PROVINCIA = {
  AO: "Valle d'Aosta",
  AL: "Piemonte", AT: "Piemonte", BI: "Piemonte", CN: "Piemonte", NO: "Piemonte", TO: "Piemonte", VB: "Piemonte", VC: "Piemonte",
  BG: "Lombardia", BS: "Lombardia", CO: "Lombardia", CR: "Lombardia", LC: "Lombardia", LO: "Lombardia", MB: "Lombardia", MI: "Lombardia", MN: "Lombardia", PV: "Lombardia", SO: "Lombardia", VA: "Lombardia",
  BZ: "Trentino-Alto Adige", TN: "Trentino-Alto Adige",
  BL: "Veneto", PD: "Veneto", RO: "Veneto", TV: "Veneto", VE: "Veneto", VI: "Veneto", VR: "Veneto",
  GO: "Friuli-Venezia Giulia", PN: "Friuli-Venezia Giulia", TS: "Friuli-Venezia Giulia", UD: "Friuli-Venezia Giulia",
  GE: "Liguria", IM: "Liguria", SP: "Liguria", SV: "Liguria",
  BO: "Emilia-Romagna", FE: "Emilia-Romagna", FC: "Emilia-Romagna", MO: "Emilia-Romagna", PC: "Emilia-Romagna", PR: "Emilia-Romagna", RA: "Emilia-Romagna", RE: "Emilia-Romagna", RN: "Emilia-Romagna",
  AR: "Toscana", FI: "Toscana", GR: "Toscana", LI: "Toscana", LU: "Toscana", MS: "Toscana", PI: "Toscana", PO: "Toscana", PT: "Toscana", SI: "Toscana",
  PG: "Umbria", TR: "Umbria",
  AN: "Marche", AP: "Marche", FM: "Marche", MC: "Marche", PU: "Marche",
  FR: "Lazio", LT: "Lazio", RI: "Lazio", RM: "Lazio", VT: "Lazio",
  AQ: "Abruzzo", CH: "Abruzzo", PE: "Abruzzo", TE: "Abruzzo",
  CB: "Molise", IS: "Molise",
  AV: "Campania", BN: "Campania", CE: "Campania", NA: "Campania", SA: "Campania",
  MT: "Basilicata", PZ: "Basilicata",
  CZ: "Calabria", CS: "Calabria", KR: "Calabria", RC: "Calabria", VV: "Calabria",
  AG: "Sicilia", CL: "Sicilia", CT: "Sicilia", EN: "Sicilia", ME: "Sicilia", PA: "Sicilia", RG: "Sicilia", SR: "Sicilia", TP: "Sicilia",
  CA: "Sardegna", NU: "Sardegna", OR: "Sardegna", SS: "Sardegna", SU: "Sardegna",
  BA: "Puglia", BR: "Puglia", BT: "Puglia", FG: "Puglia", LE: "Puglia", TA: "Puglia"
};

// Ospedali e presidi di riferimento aggiuntivi rispetto all'archivio pugliese già presente.
// La selezione è pensata per popolare il prototipo con tutte le regioni e strutture notevoli,
// senza presentarsi come censimento amministrativo completo di ogni presidio nazionale.
const OSPEDALI_NAZIONALI = [
  // Abruzzo
  ["AB-PE-01", "Ospedale Santo Spirito", "Pescara", "PE", "Abruzzo", "ASL Pescara"],
  ["AB-CH-01", "Ospedale SS. Annunziata", "Chieti", "CH", "Abruzzo", "ASL Lanciano-Vasto-Chieti"],
  ["AB-AQ-01", "Ospedale San Salvatore", "L'Aquila", "AQ", "Abruzzo", "ASL 1 Abruzzo"],
  ["AB-TE-01", "Ospedale Mazzini", "Teramo", "TE", "Abruzzo", "ASL Teramo"],
  ["AB-LA-01", "Ospedale Renzetti", "Lanciano", "CH", "Abruzzo", "ASL Lanciano-Vasto-Chieti"],
  ["AB-VA-01", "Ospedale San Pio", "Vasto", "CH", "Abruzzo", "ASL Lanciano-Vasto-Chieti"],
  // Basilicata
  ["BA-PZ-01", "Ospedale San Carlo", "Potenza", "PZ", "Basilicata", "AOR San Carlo"],
  ["BA-MT-01", "Ospedale Madonna delle Grazie", "Matera", "MT", "Basilicata", "ASM Matera"],
  ["BA-ME-01", "Ospedale di Melfi", "Melfi", "PZ", "Basilicata", "AOR San Carlo"],
  ["BA-LA-01", "Ospedale San Giovanni", "Lagonegro", "PZ", "Basilicata", "ASP Potenza"],
  ["BA-PO-01", "Ospedale Giovanni Paolo II", "Policoro", "MT", "Basilicata", "ASM Matera"],
  // Calabria
  ["CA-CZ-01", "AOU Renato Dulbecco", "Catanzaro", "CZ", "Calabria", "Azienda Ospedaliero-Universitaria"],
  ["CA-CS-01", "Ospedale Annunziata", "Cosenza", "CS", "Calabria", "Azienda Ospedaliera di Cosenza"],
  ["CA-RC-01", "Grande Ospedale Metropolitano Bianchi-Melacrino-Morelli", "Reggio Calabria", "RC", "Calabria", "GOM Reggio Calabria"],
  ["CA-KR-01", "Ospedale San Giovanni di Dio", "Crotone", "KR", "Calabria", "ASP Crotone"],
  ["CA-VV-01", "Ospedale Jazzolino", "Vibo Valentia", "VV", "Calabria", "ASP Vibo Valentia"],
  ["CA-LM-01", "Ospedale Giovanni Paolo II", "Lamezia Terme", "CZ", "Calabria", "ASP Catanzaro"],
  // Campania
  ["CM-NA-01", "AORN Antonio Cardarelli", "Napoli", "NA", "Campania", "Azienda Ospedaliera"],
  ["CM-NA-02", "AOU Federico II", "Napoli", "NA", "Campania", "Azienda Ospedaliero-Universitaria"],
  ["CM-NA-03", "Ospedale del Mare", "Napoli", "NA", "Campania", "ASL Napoli 1 Centro"],
  ["CM-NA-04", "AORN Santobono-Pausilipon", "Napoli", "NA", "Campania", "Ospedale pediatrico"],
  ["CM-SA-01", "AOU San Giovanni di Dio e Ruggi d'Aragona", "Salerno", "SA", "Campania", "Azienda Ospedaliero-Universitaria"],
  ["CM-AV-01", "AORN San Giuseppe Moscati", "Avellino", "AV", "Campania", "Azienda Ospedaliera"],
  ["CM-CE-01", "AORN Sant'Anna e San Sebastiano", "Caserta", "CE", "Campania", "Azienda Ospedaliera"],
  ["CM-BN-01", "Ospedale San Pio", "Benevento", "BN", "Campania", "Azienda Ospedaliera"],
  // Emilia-Romagna
  ["ER-BO-01", "Policlinico Sant'Orsola-Malpighi", "Bologna", "BO", "Emilia-Romagna", "Azienda Ospedaliero-Universitaria"],
  ["ER-BO-02", "Ospedale Maggiore", "Bologna", "BO", "Emilia-Romagna", "AUSL Bologna"],
  ["ER-MO-01", "Policlinico di Modena", "Modena", "MO", "Emilia-Romagna", "Azienda Ospedaliero-Universitaria"],
  ["ER-PR-01", "Ospedale Maggiore", "Parma", "PR", "Emilia-Romagna", "Azienda Ospedaliero-Universitaria"],
  ["ER-RE-01", "Arcispedale Santa Maria Nuova", "Reggio Emilia", "RE", "Emilia-Romagna", "AUSL Reggio Emilia"],
  ["ER-FE-01", "Arcispedale Sant'Anna", "Cona", "FE", "Emilia-Romagna", "Azienda Ospedaliero-Universitaria"],
  ["ER-RA-01", "Ospedale Santa Maria delle Croci", "Ravenna", "RA", "Emilia-Romagna", "AUSL Romagna"],
  ["ER-RN-01", "Ospedale Infermi", "Rimini", "RN", "Emilia-Romagna", "AUSL Romagna"],
  ["ER-FC-01", "Ospedale Bufalini", "Cesena", "FC", "Emilia-Romagna", "AUSL Romagna"],
  // Friuli-Venezia Giulia
  ["FV-TS-01", "Ospedale di Cattinara", "Trieste", "TS", "Friuli-Venezia Giulia", "ASUGI"],
  ["FV-TS-02", "Ospedale Maggiore", "Trieste", "TS", "Friuli-Venezia Giulia", "ASUGI"],
  ["FV-UD-01", "Santa Maria della Misericordia", "Udine", "UD", "Friuli-Venezia Giulia", "ASUFC"],
  ["FV-PN-01", "Ospedale Santa Maria degli Angeli", "Pordenone", "PN", "Friuli-Venezia Giulia", "ASFO"],
  ["FV-GO-01", "Ospedale San Giovanni di Dio", "Gorizia", "GO", "Friuli-Venezia Giulia", "ASUGI"],
  ["FV-MO-01", "Ospedale San Polo", "Monfalcone", "GO", "Friuli-Venezia Giulia", "ASUGI"],
  // Lazio
  ["LA-RM-01", "Policlinico Umberto I", "Roma", "RM", "Lazio", "Azienda Ospedaliero-Universitaria"],
  ["LA-RM-02", "Policlinico Universitario Agostino Gemelli", "Roma", "RM", "Lazio", "IRCCS"],
  ["LA-RM-03", "Azienda Ospedaliera San Camillo-Forlanini", "Roma", "RM", "Lazio", "Azienda Ospedaliera"],
  ["LA-RM-04", "AOU Sant'Andrea", "Roma", "RM", "Lazio", "Azienda Ospedaliero-Universitaria"],
  ["LA-RM-05", "Policlinico Tor Vergata", "Roma", "RM", "Lazio", "Azienda Ospedaliera Universitaria"],
  ["LA-RM-06", "Ospedale Pediatrico Bambino Gesù", "Roma", "RM", "Lazio", "IRCCS pediatrico"],
  ["LA-LT-01", "Ospedale Santa Maria Goretti", "Latina", "LT", "Lazio", "ASL Latina"],
  ["LA-VT-01", "Ospedale Belcolle", "Viterbo", "VT", "Lazio", "ASL Viterbo"],
  ["LA-FR-01", "Ospedale Fabrizio Spaziani", "Frosinone", "FR", "Lazio", "ASL Frosinone"],
  ["LA-RI-01", "Ospedale San Camillo de Lellis", "Rieti", "RI", "Lazio", "ASL Rieti"],
  // Liguria
  ["LI-GE-01", "Ospedale Policlinico San Martino", "Genova", "GE", "Liguria", "IRCCS"],
  ["LI-GE-02", "Ospedale Galliera", "Genova", "GE", "Liguria", "Ente ospedaliero"],
  ["LI-GE-03", "Ospedale Villa Scassi", "Genova", "GE", "Liguria", "ASL 3"],
  ["LI-GE-04", "IRCCS Istituto Giannina Gaslini", "Genova", "GE", "Liguria", "IRCCS pediatrico"],
  ["LI-SV-01", "Ospedale San Paolo", "Savona", "SV", "Liguria", "ASL 2"],
  ["LI-IM-01", "Ospedale Borea", "Sanremo", "IM", "Liguria", "ASL 1"],
  ["LI-SP-01", "Ospedale Sant'Andrea", "La Spezia", "SP", "Liguria", "ASL 5"],
  // Lombardia
  ["LO-MI-01", "Grande Ospedale Metropolitano Niguarda", "Milano", "MI", "Lombardia", "ASST"],
  ["LO-MI-02", "Policlinico di Milano", "Milano", "MI", "Lombardia", "Fondazione IRCCS"],
  ["LO-MI-03", "Ospedale San Raffaele", "Milano", "MI", "Lombardia", "IRCCS"],
  ["LO-BG-01", "Ospedale Papa Giovanni XXIII", "Bergamo", "BG", "Lombardia", "ASST"],
  ["LO-BS-01", "Spedali Civili", "Brescia", "BS", "Lombardia", "ASST"],
  ["LO-PV-01", "Policlinico San Matteo", "Pavia", "PV", "Lombardia", "Fondazione IRCCS"],
  ["LO-VA-01", "Ospedale di Circolo e Fondazione Macchi", "Varese", "VA", "Lombardia", "ASST Sette Laghi"],
  ["LO-MB-01", "Ospedale San Gerardo", "Monza", "MB", "Lombardia", "Fondazione IRCCS"],
  ["LO-CR-01", "Ospedale Maggiore", "Cremona", "CR", "Lombardia", "ASST Cremona"],
  ["LO-MN-01", "Ospedale Carlo Poma", "Mantova", "MN", "Lombardia", "ASST Mantova"],
  // Marche
  ["MA-AN-01", "AOU delle Marche - Ospedali Riuniti", "Ancona", "AN", "Marche", "Azienda Ospedaliero-Universitaria"],
  ["MA-AN-02", "Ospedale Salesi", "Ancona", "AN", "Marche", "Ospedale pediatrico"],
  ["MA-PU-01", "Ospedale San Salvatore", "Pesaro", "PU", "Marche", "AST Pesaro Urbino"],
  ["MA-MC-01", "Ospedale di Macerata", "Macerata", "MC", "Marche", "AST Macerata"],
  ["MA-AP-01", "Ospedale Mazzoni", "Ascoli Piceno", "AP", "Marche", "AST Ascoli Piceno"],
  ["MA-FM-01", "Ospedale Murri", "Fermo", "FM", "Marche", "AST Fermo"],
  // Molise
  ["MO-CB-01", "Ospedale Cardarelli", "Campobasso", "CB", "Molise", "ASREM"],
  ["MO-IS-01", "Ospedale Veneziale", "Isernia", "IS", "Molise", "ASREM"],
  ["MO-TE-01", "Ospedale San Timoteo", "Termoli", "CB", "Molise", "ASREM"],
  // Piemonte
  ["PI-TO-01", "Città della Salute e della Scienza - Molinette", "Torino", "TO", "Piemonte", "Azienda Ospedaliero-Universitaria"],
  ["PI-TO-02", "Ospedale Mauriziano Umberto I", "Torino", "TO", "Piemonte", "Azienda Ospedaliera"],
  ["PI-TO-03", "Ospedale Maria Vittoria", "Torino", "TO", "Piemonte", "ASL Città di Torino"],
  ["PI-NO-01", "Ospedale Maggiore della Carità", "Novara", "NO", "Piemonte", "AOU Maggiore della Carità"],
  ["PI-CN-01", "Ospedale Santa Croce e Carle", "Cuneo", "CN", "Piemonte", "Azienda Ospedaliera"],
  ["PI-AL-01", "Azienda Ospedaliera SS. Antonio e Biagio e Cesare Arrigo", "Alessandria", "AL", "Piemonte", "Azienda Ospedaliera"],
  ["PI-AT-01", "Ospedale Cardinal Massaia", "Asti", "AT", "Piemonte", "ASL AT"],
  ["PI-VC-01", "Ospedale Sant'Andrea", "Vercelli", "VC", "Piemonte", "ASL Vercelli"],
  // Sardegna
  ["SA-CA-01", "Ospedale San Michele - ARNAS G. Brotzu", "Cagliari", "CA", "Sardegna", "ARNAS"],
  ["SA-CA-02", "Policlinico Duilio Casula", "Monserrato", "CA", "Sardegna", "AOU Cagliari"],
  ["SA-SS-01", "AOU di Sassari - Ospedale Santissima Annunziata", "Sassari", "SS", "Sardegna", "Azienda Ospedaliero-Universitaria"],
  ["SA-NU-01", "Ospedale San Francesco", "Nuoro", "NU", "Sardegna", "ASL Nuoro"],
  ["SA-OR-01", "Ospedale San Martino", "Oristano", "OR", "Sardegna", "ASL Oristano"],
  ["SA-OL-01", "Ospedale Giovanni Paolo II", "Olbia", "SS", "Sardegna", "ASL Gallura"],
  // Sicilia
  ["SI-PA-01", "ARNAS Ospedale Civico Di Cristina Benfratelli", "Palermo", "PA", "Sicilia", "ARNAS"],
  ["SI-PA-02", "Policlinico Paolo Giaccone", "Palermo", "PA", "Sicilia", "Azienda Ospedaliero-Universitaria"],
  ["SI-PA-03", "Ospedale Villa Sofia-Cervello", "Palermo", "PA", "Sicilia", "Azienda Ospedaliera"],
  ["SI-CT-01", "ARNAS Garibaldi", "Catania", "CT", "Sicilia", "ARNAS"],
  ["SI-CT-02", "AOU Policlinico G. Rodolico - San Marco", "Catania", "CT", "Sicilia", "Azienda Ospedaliero-Universitaria"],
  ["SI-ME-01", "AOU G. Martino", "Messina", "ME", "Sicilia", "Azienda Ospedaliero-Universitaria"],
  ["SI-ME-02", "Ospedale Papardo", "Messina", "ME", "Sicilia", "Azienda Ospedaliera"],
  ["SI-SR-01", "Ospedale Umberto I", "Siracusa", "SR", "Sicilia", "ASP Siracusa"],
  ["SI-AG-01", "Ospedale San Giovanni di Dio", "Agrigento", "AG", "Sicilia", "ASP Agrigento"],
  ["SI-TP-01", "Ospedale Sant'Antonio Abate", "Trapani", "TP", "Sicilia", "ASP Trapani"],
  // Toscana
  ["TO-FI-01", "AOU Careggi", "Firenze", "FI", "Toscana", "Azienda Ospedaliero-Universitaria"],
  ["TO-FI-02", "Ospedale Santa Maria Nuova", "Firenze", "FI", "Toscana", "AUSL Toscana Centro"],
  ["TO-FI-03", "AOU Meyer", "Firenze", "FI", "Toscana", "IRCCS pediatrico"],
  ["TO-PI-01", "AOU Pisana - Ospedale Cisanello", "Pisa", "PI", "Toscana", "Azienda Ospedaliero-Universitaria"],
  ["TO-SI-01", "AOU Senese - Le Scotte", "Siena", "SI", "Toscana", "Azienda Ospedaliero-Universitaria"],
  ["TO-LU-01", "Ospedale San Luca", "Lucca", "LU", "Toscana", "AUSL Toscana Nord Ovest"],
  ["TO-LI-01", "Ospedale di Livorno", "Livorno", "LI", "Toscana", "AUSL Toscana Nord Ovest"],
  ["TO-AR-01", "Ospedale San Donato", "Arezzo", "AR", "Toscana", "AUSL Toscana Sud Est"],
  // Trentino-Alto Adige
  ["TA-TN-01", "Ospedale Santa Chiara", "Trento", "TN", "Trentino-Alto Adige", "Azienda Provinciale per i Servizi Sanitari"],
  ["TA-TN-02", "Ospedale Santa Maria del Carmine", "Rovereto", "TN", "Trentino-Alto Adige", "APSS"],
  ["TA-BZ-01", "Ospedale di Bolzano", "Bolzano", "BZ", "Trentino-Alto Adige", "Azienda Sanitaria dell'Alto Adige"],
  ["TA-BZ-02", "Ospedale di Merano", "Merano", "BZ", "Trentino-Alto Adige", "Azienda Sanitaria dell'Alto Adige"],
  ["TA-BZ-03", "Ospedale di Bressanone", "Bressanone", "BZ", "Trentino-Alto Adige", "Azienda Sanitaria dell'Alto Adige"],
  ["TA-BZ-04", "Ospedale di Brunico", "Brunico", "BZ", "Trentino-Alto Adige", "Azienda Sanitaria dell'Alto Adige"],
  // Umbria
  ["UM-PG-01", "Azienda Ospedaliera di Perugia - Santa Maria della Misericordia", "Perugia", "PG", "Umbria", "Azienda Ospedaliera"],
  ["UM-TR-01", "Azienda Ospedaliera Santa Maria", "Terni", "TR", "Umbria", "Azienda Ospedaliera"],
  ["UM-PG-02", "Ospedale San Giovanni Battista", "Foligno", "PG", "Umbria", "USL Umbria 2"],
  ["UM-PG-03", "Ospedale di Città di Castello", "Città di Castello", "PG", "Umbria", "USL Umbria 1"],
  // Valle d'Aosta
  ["VA-AO-01", "Ospedale regionale Umberto Parini", "Aosta", "AO", "Valle d'Aosta", "Azienda USL Valle d'Aosta"],
  // Veneto
  ["VE-PD-01", "Azienda Ospedale-Università di Padova", "Padova", "PD", "Veneto", "Azienda Ospedaliera-Universitaria"],
  ["VE-VR-01", "AOUI Verona - Borgo Trento", "Verona", "VR", "Veneto", "Azienda Ospedaliera-Universitaria"],
  ["VE-VR-02", "AOUI Verona - Borgo Roma", "Verona", "VR", "Veneto", "Azienda Ospedaliera-Universitaria"],
  ["VE-VE-01", "Ospedale dell'Angelo", "Mestre", "VE", "Veneto", "AULSS 3 Serenissima"],
  ["VE-TV-01", "Ospedale Ca' Foncello", "Treviso", "TV", "Veneto", "AULSS 2 Marca Trevigiana"],
  ["VE-VI-01", "Ospedale San Bortolo", "Vicenza", "VI", "Veneto", "AULSS 8 Berica"],
  ["VE-RO-01", "Ospedale Santa Maria della Misericordia", "Rovigo", "RO", "Veneto", "AULSS 5 Polesana"],
  ["VE-BL-01", "Ospedale San Martino", "Belluno", "BL", "Veneto", "AULSS 1 Dolomiti"]
].map(([id, nome, citta, provincia, regione, ente]) => ({
  id, nome, citta, provincia, regione, ente, livello: "Presidio ospedaliero"
}));

// Completa la regione delle 37 strutture pugliesi già incluse nella banca dati originaria.
OSPEDALI.forEach(o => { o.regione = REGIONE_PROVINCIA[o.provincia] || "Puglia"; });
const ospedaliGiaPresenti = new Set(OSPEDALI.map(o => o.id));
OSPEDALI_NAZIONALI.forEach(o => { if (!ospedaliGiaPresenti.has(o.id)) OSPEDALI.push(o); });

// Profili sintetici e deterministici: gli stessi pazienti appaiono a ogni apertura del sito.
const NOMI_FITTIZI = ["Alessandro", "Anna", "Andrea", "Aurora", "Beatrice", "Carlo", "Chiara", "Davide", "Elena", "Filippo", "Francesca", "Gabriele", "Giorgia", "Giulia", "Giorgio", "Irene", "Lorenzo", "Luca", "Martina", "Matteo", "Michela", "Nicola", "Paola", "Riccardo", "Sara", "Sofia", "Tommaso", "Valentina", "Vittoria", "Marco"];
const COGNOMI_FITTIZI = ["Rossi", "Bianchi", "Romano", "Gallo", "Costa", "Fontana", "Conti", "Esposito", "Ricci", "Bruno", "Greco", "Marino", "Lombardi", "Barbieri", "Moretti", "Giordano", "Caruso", "Ferrari", "Rizzo", "De Luca", "Mancini", "Longo", "Gentile", "Martinelli", "Vitale", "Serra", "Pellegrini", "Colombo", "Marchetti", "Ferri"];
const GRUPPI_FITTIZI = ["0+", "0-", "A+", "A-", "B+", "B-", "AB+", "AB-"];

const ospedaliConProfiliDemo = OSPEDALI.filter(o => !ospedaliGiaPresenti.has(o.id));
ospedaliConProfiliDemo.forEach((o, indiceOspedale) => {
  for (let i = 1; i <= 8; i++) {
    const anno = 1942 + ((indiceOspedale * 11 + i * 7) % 73);
    const mese = ((indiceOspedale + i * 3) % 12) + 1;
    const giorno = ((indiceOspedale * 5 + i * 9) % 27) + 1;
    PAZIENTI.push({
      id: `${o.id}-${String(i).padStart(3, "0")}`,
      ospedale: o.id,
      nome: NOMI_FITTIZI[(indiceOspedale * 3 + i * 5) % NOMI_FITTIZI.length],
      cognome: COGNOMI_FITTIZI[(indiceOspedale * 7 + i * 3) % COGNOMI_FITTIZI.length],
      sesso: (indiceOspedale + i) % 2 ? "F" : "M",
      nascita: `${anno}-${String(mese).padStart(2, "0")}-${String(giorno).padStart(2, "0")}`,
      gruppo_sanguigno: GRUPPI_FITTIZI[(indiceOspedale + i * 2) % GRUPPI_FITTIZI.length],
      malattie: []
    });
  }
});
