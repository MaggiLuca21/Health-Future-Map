// Parte COMUNE ai due siti: archivio dei dati inseriti e scelta ospedale → paziente.
// I dati inseriti (malattie, scansioni, analisi, piani) restano nel browser (localStorage).
// Con "Esporta" si salvano in un file .json da portare su un altro computer e "Importa" li ricarica.

// Memoria del browser: se il browser la blocca (Safari con file aperti dal disco, navigazione privata)
// si usa una memoria temporanea che dura finché la pagina resta aperta.
function memoria(tipo) {
  try { const m = window[tipo]; m.setItem("_prova", "1"); m.removeItem("_prova"); return m; } catch {}
  const dati = {};
  return { getItem: k => (k in dati ? dati[k] : null), setItem: (k, v) => { dati[k] = String(v); }, removeItem: k => { delete dati[k]; } };
}
const Memoria = memoria("localStorage");
const Sessione = memoria("sessionStorage");

const Archivio = {
  CHIAVE: "progetti_scuola_archivio",
  tutto() {
    try { return JSON.parse(Memoria.getItem(this.CHIAVE) || "{}"); } catch { return {}; }
  },
  scrivi(dati) {
    try { Memoria.setItem(this.CHIAVE, JSON.stringify(dati)); } catch { alert("Impossibile salvare nel browser."); }
  },
  leggi(id) {
    const r = this.tutto()[id] || {};
    return { malattie: [], scansioni: [], analisi: [], piano: null, sedute: [], ...r };
  },
  aggiorna(id, modifica) {
    const dati = this.tutto();
    const r = this.leggi(id);
    modifica(r);
    dati[id] = r;
    this.scrivi(dati);
    return r;
  },
  esporta() {
    const blob = new Blob([JSON.stringify(this.tutto(), null, 1)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "archivio-pazienti-" + new Date().toISOString().slice(0, 10) + ".json";
    a.click();
  },
  importa(file, fatto) {
    file.text().then(t => {
      const nuovi = JSON.parse(t);
      this.scrivi({ ...this.tutto(), ...nuovi });
      fatto && fatto(Object.keys(nuovi).length);
    }).catch(() => alert("File non valido."));
  }
};


const CHIAVE_PAZIENTI_AGGIUNTI = "health_future_map_pazienti_aggiunti";

// Le persone aggiunte dal modulo vengono salvate nel browser e ricaricate a ogni apertura.
function leggiPazientiAggiunti() {
  try {
    const dati = JSON.parse(Memoria.getItem(CHIAVE_PAZIENTI_AGGIUNTI) || "[]");
    return Array.isArray(dati) ? dati : [];
  } catch { return []; }
}

const PAZIENTI_AGGIUNTI = leggiPazientiAggiunti();
PAZIENTI.push(...PAZIENTI_AGGIUNTI.filter(p => p && p.id && !PAZIENTI.some(esistente => esistente.id === p.id)));

function prossimoIdPaziente(idOspedale) {
  const ultimo = PAZIENTI
    .filter(p => p.ospedale === idOspedale)
    .reduce((max, p) => {
      const match = String(p.id).match(/-(\d+)$/);
      return match ? Math.max(max, Number(match[1])) : max;
    }, 0);
  return `${idOspedale}-${String(ultimo + 1).padStart(3, "0")}`;
}

function salvaPazienteAggiunto(nuovo) {
  if (PAZIENTI.some(p => p.id === nuovo.id)) throw new Error("Esiste già una persona con questo codice.");
  const aggiunti = leggiPazientiAggiunti();
  aggiunti.push(nuovo);
  Memoria.setItem(CHIAVE_PAZIENTI_AGGIUNTI, JSON.stringify(aggiunti));
  PAZIENTI.push(nuovo);
}

function salvaModifichePaziente(paziente) {
  const aggiunti = leggiPazientiAggiunti();
  const indice = aggiunti.findIndex(p => p.id === paziente.id);
  if (indice !== -1) {
    aggiunti[indice] = paziente;
    Memoria.setItem(CHIAVE_PAZIENTI_AGGIUNTI, JSON.stringify(aggiunti));
  }
}

const ospedale = id => OSPEDALI.find(o => o.id === id);
const persona = id => PAZIENTI.find(p => p.id === id);
const nomeCompleto = p => `${p.cognome} ${p.nome}`;
const eta = p => Math.floor((Date.now() - new Date(p.nascita)) / 3.15576e10);
const dataIt = d => new Date(d).toLocaleDateString("it-IT");
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

// Selezione corrente condivisa tra le pagine dello stesso sito
const Scelta = {
  get regione() { return Sessione.getItem("scelta_regione") || ""; },
  set regione(v) { Sessione.setItem("scelta_regione", v); },
  get provincia() { return Sessione.getItem("scelta_provincia") || ""; },
  set provincia(v) { Sessione.setItem("scelta_provincia", v); },
  get ospedale() { return Sessione.getItem("scelta_ospedale") || ""; },
  set ospedale(v) { Sessione.setItem("scelta_ospedale", v); },
  get paziente() { return Sessione.getItem("scelta_paziente") || ""; },
  set paziente(v) { Sessione.setItem("scelta_paziente", v); }
};

// Disegna il blocco "scegli ospedale → scegli paziente" dentro l'elemento con id `dove`.
// `alScegliere(idPaziente)` viene chiamata quando si clicca su una persona.
function selettoreOspedalePaziente(dove, alScegliere, etichettaBottone = "Scegli") {
  const el = document.getElementById(dove);
  let regione = Scelta.regione;
  let prov = Scelta.provincia;
  let cerca = "";

  function disegna() {
    const ospedaliRegione = OSPEDALI.filter(o => !regione || o.regione === regione);
    const provinceVisibili = [...new Set(ospedaliRegione.map(o => o.provincia))]
      .sort((a, b) => (PROVINCE[a] || a).localeCompare(PROVINCE[b] || b, "it"));
    if (prov && !provinceVisibili.includes(prov)) prov = "";
    const ospedaliVisibili = ospedaliRegione.filter(o => !prov || o.provincia === prov)
      .sort((a, b) => a.citta.localeCompare(b.citta, "it") || a.nome.localeCompare(b.nome, "it"));
    if (Scelta.ospedale && !ospedaliVisibili.some(o => o.id === Scelta.ospedale)) {
      Scelta.ospedale = "";
      Scelta.paziente = "";
    }
    const persone = Scelta.ospedale
      ? PAZIENTI.filter(p => p.ospedale === Scelta.ospedale && nomeCompleto(p).toLowerCase().includes(cerca.toLowerCase()))
      : [];
    const strutturaSelezionata = ospedale(Scelta.ospedale);
    el.innerHTML = `
      <div class="griglia selettore-nazionale" style="grid-template-columns:repeat(3,minmax(0,1fr));width:100%;min-width:0">
        <div class="campo"><label>Regione</label>
          <select data-k="regione"><option value="">Tutte le regioni</option>
          ${REGIONI_ITALIANE.map(r => `<option value="${esc(r)}" ${r === regione ? "selected" : ""}>${esc(r)}</option>`).join("")}
          </select></div>
        <div class="campo"><label>Provincia</label>
          <select data-k="prov"><option value="">Tutte le province</option>
          ${provinceVisibili.map(k => `<option value="${k}" ${k === prov ? "selected" : ""}>${esc(PROVINCE[k] || k)}</option>`).join("")}
          </select></div>
        <div class="campo"><label>Ospedale (${ospedaliVisibili.length})</label>
          <select data-k="osp"><option value="">— scegli l'ospedale —</option>
          ${ospedaliVisibili.map(o => `<option value="${o.id}" ${o.id === Scelta.ospedale ? "selected" : ""}>${esc(o.citta)} · ${esc(o.nome)}</option>`).join("")}
          </select></div>
      </div>
      ${Scelta.ospedale && strutturaSelezionata ? `
        <p class="sotto">${esc(strutturaSelezionata.regione)} · ${esc(strutturaSelezionata.ente)} · ${esc(strutturaSelezionata.livello)}</p>
        <div class="campo" style="max-width:340px"><input data-k="cerca" placeholder="Cerca per cognome o nome" value="${esc(cerca)}"></div>
        <div class="tabella-scroll" style="max-height:420px;overflow:auto"><table>
          <tr><th>Codice</th><th>Cognome e nome</th><th>Età</th><th>Sesso</th><th>Malattie</th><th></th></tr>
          ${persone.map(p => {
            const r = Archivio.leggi(p.id), mal = [...new Set([...(p.malattie || []), ...r.malattie])];
            return `<tr class="${p.id === Scelta.paziente ? "scelto" : ""}">
              <td class="mono">${p.id}</td><td>${esc(nomeCompleto(p))}</td><td>${eta(p)}</td><td>${p.sesso}</td>
              <td>${mal.length ? mal.map(m => `<span class="etichetta">${esc(m)}</span>`).join("") : '<span class="sotto">nessuna</span>'}</td>
              <td><button class="btn piccolo" data-p="${p.id}">${etichettaBottone}</button></td></tr>`;
          }).join("") || `<tr><td colspan="6">Nessuna persona trovata.</td></tr>`}
        </table></div>` : `<p class="sotto">Scegli una regione, una provincia e un ospedale per vedere i profili fittizi registrati.</p>`}`;

    el.querySelector('[data-k="regione"]').onchange = e => {
      regione = e.target.value; Scelta.regione = regione; prov = ""; Scelta.provincia = "";
      Scelta.ospedale = ""; Scelta.paziente = ""; cerca = ""; disegna();
    };
    el.querySelector('[data-k="prov"]').onchange = e => {
      prov = e.target.value; Scelta.provincia = prov; Scelta.ospedale = ""; Scelta.paziente = ""; cerca = ""; disegna();
    };
    el.querySelector('[data-k="osp"]').onchange = e => {
      Scelta.ospedale = e.target.value; Scelta.paziente = ""; cerca = ""; disegna();
    };
    const c = el.querySelector('[data-k="cerca"]');
    if (c) c.oninput = e => {
      cerca = e.target.value; const pos = e.target.selectionStart; disegna();
      const n = el.querySelector('[data-k="cerca"]'); n.focus(); n.setSelectionRange(pos, pos);
    };
    el.querySelectorAll("[data-p]").forEach(b => b.onclick = () => {
      Scelta.paziente = b.dataset.p;
      const p = persona(Scelta.paziente);
      if (p) FilePazienti.creaCartellaPaziente(p.id);
      alScegliere(b.dataset.p);
    });
  }
  disegna();
}

// Riquadro con la persona scelta
function riquadroPaziente(id) {
  const p = persona(id); if (!p) return "";
  const o = ospedale(p.ospedale);
  if (!o) return "";
  return `<div class="scheda paziente-scelto">
    <b>${esc(nomeCompleto(p))}</b> · ${eta(p)} anni · ${p.sesso} · gruppo ${p.gruppo_sanguigno}<br>
    <span class="sotto">${p.id} · ${esc(o.nome)}, ${esc(o.citta)} (${esc(o.regione)})</span>
  </div>`;
}

// Bottoni Esporta / Importa
function bottoniArchivio() {
  return `<p>
    <button class="btn secondario" onclick="Archivio.esporta()">Esporta i dati inseriti</button>
    <label class="btn secondario">Importa dati<input type="file" accept=".json" hidden
      onchange="Archivio.importa(this.files[0], n => { alert(n + ' schede importate'); mostra(); })"></label>
  </p>`;
}


// Archivio virtuale del sito: salva i PDF in IndexedDB e mostra le cartelle nell'interfaccia.
// Un sito statico aperto come file:// non può creare directory reali accanto a index.html.
const FilePazienti = (() => {
  const CHIAVE_META = "health_future_map_file_pazienti_v1";
  const CHIAVE_CARTELLE = "health_future_map_cartelle_pazienti_v1";
  const DB_NAME = "health_future_map_file_pazienti";
  const STORE = "pdf";

  function leggiMeta() {
    try {
      const x = JSON.parse(Memoria.getItem(CHIAVE_META) || "[]");
      return Array.isArray(x) ? x : [];
    } catch { return []; }
  }
  function scriviMeta(files) {
    try { Memoria.setItem(CHIAVE_META, JSON.stringify(files)); }
    catch { alert("Spazio di archiviazione insufficiente per aggiornare l'indice dei file."); }
  }
  function leggiCartelle() {
    try {
      const x = JSON.parse(Memoria.getItem(CHIAVE_CARTELLE) || "[]");
      return Array.isArray(x) ? x : [];
    } catch { return []; }
  }
  function scriviCartelle(cartelle) {
    try { Memoria.setItem(CHIAVE_CARTELLE, JSON.stringify(cartelle)); } catch {}
  }
  function apriDB() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) return resolve(null);
      let richiesta;
      try { richiesta = indexedDB.open(DB_NAME, 1); } catch (e) { reject(e); return; }
      richiesta.onupgradeneeded = () => {
        const db = richiesta.result;
        if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
      };
      richiesta.onsuccess = () => resolve(richiesta.result);
      richiesta.onerror = () => reject(richiesta.error || new Error("IndexedDB non disponibile"));
    });
  }
  function blobBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  }
  async function salvaBinario(id, blob) {
    try {
      const db = await apriDB();
      if (db) {
        await new Promise((resolve, reject) => {
          const tx = db.transaction(STORE, "readwrite");
          tx.objectStore(STORE).put({ id, blob });
          tx.oncomplete = resolve;
          tx.onerror = () => reject(tx.error);
          tx.onabort = () => reject(tx.error || new Error("Salvataggio annullato"));
        });
        db.close();
        return;
      }
    } catch (e) { console.warn("Archivio PDF IndexedDB non disponibile; provo l'archivio locale alternativo.", e); }
    const base64 = await blobBase64(blob);
    const fallback = JSON.parse(Memoria.getItem("health_future_map_pdf_fallback_v1") || "{}");
    fallback[id] = { type: blob.type || "application/pdf", base64 };
    Memoria.setItem("health_future_map_pdf_fallback_v1", JSON.stringify(fallback));
  }
  async function leggiBinario(id) {
    try {
      const db = await apriDB();
      if (db) {
        const record = await new Promise((resolve, reject) => {
          const tx = db.transaction(STORE, "readonly");
          const req = tx.objectStore(STORE).get(id);
          req.onsuccess = () => resolve(req.result || null);
          req.onerror = () => reject(req.error);
        });
        db.close();
        if (record && record.blob) return record.blob;
      }
    } catch (e) { console.warn("Lettura PDF da IndexedDB non riuscita.", e); }
    try {
      const fallback = JSON.parse(Memoria.getItem("health_future_map_pdf_fallback_v1") || "{}");
      const x = fallback[id];
      if (!x) return null;
      const raw = atob(x.base64);
      const bytes = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
      return new Blob([bytes], { type: x.type || "application/pdf" });
    } catch { return null; }
  }
  function pulisciNome(s) {
    return String(s || "paziente").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9_-]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 70) || "paziente";
  }
  async function sincronizzaCartellaFisica(p, o) {
    if (!window.HFM_STORAGE_MODE || !p || !o) return;
    try {
      await fetch("/api/cartella", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paziente: p, ospedale: o })
      });
    } catch (e) { console.warn("Cartella fisica non sincronizzata; resta attivo l'archivio locale.", e); }
  }
  function creaCartellaPaziente(id) {
    if (!id) return;
    const p = persona(id);
    const o = p && ospedale(p.ospedale);
    if (!p || !o) return;
    sincronizzaCartellaFisica(p, o);
    const cartelle = leggiCartelle();
    if (!cartelle.some(c => c.pazienteId === id)) {
      cartelle.push({ pazienteId: id, creataIl: new Date().toISOString() });
      scriviCartelle(cartelle);
    }
  }
  function prossimaSessione(pazienteId) {
    return leggiMeta().filter(f => f.pazienteId === pazienteId).reduce((n, f) => Math.max(n, Number(f.sessione) || 0), 0) + 1;
  }
  async function archiviaPDF({ pazienteId, report, sessione: sessioneRichiesta }) {
    const p = persona(pazienteId);
    const o = p && ospedale(p.ospedale);
    if (!p || !o) throw new Error("Seleziona prima un paziente valido.");
    creaCartellaPaziente(pazienteId);
    const files = leggiMeta();
    const sessione = Math.max(prossimaSessione(pazienteId), Number(sessioneRichiesta) || 1);
    const data = new Date();
    const dataBreve = data.toISOString().slice(0, 10);
    const numero = String(sessione).padStart(3, "0");
    const filename = `Report_${pulisciNome(p.cognome)}_${pulisciNome(p.nome)}_Sessione_${numero}_${dataBreve}.pdf`;
    const id = `pdf_${pulisciNome(pazienteId)}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const blob = new Blob([report], { type: "application/pdf" });
    await salvaBinario(id, blob);
    if (window.HFM_STORAGE_MODE) {
      try {
        const bytes = new Uint8Array(await blob.arrayBuffer());
        let binary = "";
        for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
        const base64 = btoa(binary);
        const risposta = await fetch("/api/pdf", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ paziente: p, ospedale: o, filename, sessione, data: dataBreve, base64 })
        });
        if (!risposta.ok) throw new Error("Scrittura PDF non riuscita");
      } catch (e) { console.warn("PDF conservato nell'archivio browser; copia fisica non riuscita.", e); }
    }
    const entry = {
      id, pazienteId, pazienteNome: nomeCompleto(p), regione: o.regione || REGIONE_PROVINCIA[o.provincia] || "Italia",
      ospedaleId: o.id, ospedaleNome: o.nome, citta: o.citta, sessione, data: dataBreve,
      filename, dimensione: blob.size,
      percorso: `Cartelle pazienti/${o.regione || REGIONE_PROVINCIA[o.provincia] || "Italia"}/${o.nome}/${p.id} - ${p.cognome} ${p.nome}/Sessione ${numero}/${filename}`
    };
    files.push(entry);
    scriviMeta(files);
    return entry;
  }
  async function scarica(id) {
    const entry = leggiMeta().find(f => f.id === id);
    const blob = await leggiBinario(id);
    if (!entry || !blob) { alert("Il PDF non è disponibile nell'archivio locale."); return; }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = entry.filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
  async function apri(id) {
    const blob = await leggiBinario(id);
    if (!blob) { alert("Il PDF non è disponibile nell'archivio locale."); return; }
    const url = URL.createObjectURL(blob);
    const finestra = window.open(url, "_blank", "noopener");
    if (!finestra) scarica(id);
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
  async function resetta() {
    Memoria.removeItem(CHIAVE_META);
    Memoria.removeItem(CHIAVE_CARTELLE);
    Memoria.removeItem("health_future_map_pdf_fallback_v1");
    if (!window.indexedDB) return;
    await new Promise(resolve => {
      const richiesta = indexedDB.deleteDatabase(DB_NAME);
      richiesta.onsuccess = richiesta.onerror = richiesta.onblocked = () => resolve();
    });
  }
  return { lista: leggiMeta, cartelle: leggiCartelle, creaCartellaPaziente, prossimaSessione, archiviaPDF, scarica, apri, resetta };
})();
