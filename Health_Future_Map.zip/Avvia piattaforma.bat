@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js non e' installato.
  echo Installa la versione LTS da https://nodejs.org/ e poi riapri questo file.
  pause
  start "" "https://nodejs.org/"
  exit /b 1
)
start "" http://127.0.0.1:4173
node server.js
pause
