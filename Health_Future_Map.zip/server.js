const http = require("http");
const fs = require("fs");
const path = require("path");
const ROOT = __dirname;
const ARCHIVIO = path.join(ROOT, "Cartelle pazienti");
const PORT = Number(process.env.PORT || 4173);
const MIME = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".json":"application/json; charset=utf-8", ".txt":"text/plain; charset=utf-8", ".fasta":"text/plain; charset=utf-8", ".fa":"text/plain; charset=utf-8" };

function safePart(value) {
  return String(value || "Senza nome").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9 _().-]/g, "_").replace(/[. ]+$/g, "").trim().slice(0, 100) || "Senza nome";
}
function hospitalDir(o) {
  return path.join(ARCHIVIO, safePart(o.regione || "Italia"), safePart(`${o.nome || "Struttura"} - ${o.citta || ""}`));
}
function patientDir(p, o) {
  return path.join(hospitalDir(o), safePart(`${p.id} - ${p.cognome || ""} ${p.nome || ""}`));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = ""; req.on("data", chunk => { raw += chunk; if (raw.length > 45 * 1024 * 1024) { reject(new Error("Richiesta troppo grande")); req.destroy(); } });
    req.on("end", () => { try { resolve(JSON.parse(raw || "{}")); } catch { reject(new Error("JSON non valido")); } });
    req.on("error", reject);
  });
}
function json(res, code, obj) { res.writeHead(code, { "Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store" }); res.end(JSON.stringify(obj)); }
async function handle(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (req.method === "GET" && url.pathname === "/api/stato") return json(res, 200, { ok:true });
  if (req.method === "POST" && url.pathname.startsWith("/api/")) {
    try {
      const data = await readBody(req);
      if (url.pathname === "/api/inizializza") {
        fs.mkdirSync(ARCHIVIO, { recursive:true });
        for (const o of (Array.isArray(data.ospedali) ? data.ospedali : [])) fs.mkdirSync(hospitalDir(o), { recursive:true });
        for (const p of (Array.isArray(data.pazienti) ? data.pazienti : [])) {
          const o = (data.ospedali || []).find(x => x.id === p.ospedale);
          if (o) fs.mkdirSync(patientDir(p, o), { recursive:true });
        }
        return json(res, 200, { ok:true });
      }
      if (url.pathname === "/api/cartella") {
        if (!data.paziente || !data.ospedale) return json(res, 400, { error:"Dati mancanti" });
        fs.mkdirSync(patientDir(data.paziente, data.ospedale), { recursive:true });
        return json(res, 200, { ok:true });
      }
      if (url.pathname === "/api/pdf") {
        if (!data.paziente || !data.ospedale || typeof data.base64 !== "string") return json(res, 400, { error:"Dati mancanti" });
        const dir = path.join(patientDir(data.paziente, data.ospedale), `Sessione ${String(data.sessione || 1).padStart(3,"0")}`);
        fs.mkdirSync(dir, { recursive:true });
        const filename = safePart(data.filename || "Report.pdf");
        fs.writeFileSync(path.join(dir, filename), Buffer.from(data.base64, "base64"));
        return json(res, 200, { ok:true });
      }
      return json(res, 404, { error:"Endpoint inesistente" });
    } catch (e) { return json(res, 500, { error:e.message }); }
  }
  if (req.method !== "GET" && req.method !== "HEAD") return json(res, 405, { error:"Metodo non consentito" });
  let pathname = decodeURIComponent(url.pathname === "/" ? "/index.html" : url.pathname);
  if (pathname === "/Cartelle pazienti" || pathname.startsWith("/Cartelle pazienti/")) return json(res, 403, { error:"Archivio locale non esposto via HTTP" });
  const file = path.resolve(ROOT, "." + pathname);
  if (!file.startsWith(ROOT + path.sep) && file !== path.join(ROOT, "index.html")) return json(res, 403, { error:"Accesso negato" });
  fs.readFile(file, (err, bytes) => {
    if (err) { res.writeHead(404); return res.end("File non trovato"); }
    res.writeHead(200, { "Content-Type":MIME[path.extname(file)] || "application/octet-stream", "X-Content-Type-Options":"nosniff" });
    if (req.method === "HEAD") return res.end();
    res.end(bytes);
  });
}
http.createServer((req,res) => { handle(req,res).catch(e => json(res,500,{error:e.message})); })
.listen(PORT, "127.0.0.1", () => {
  console.log(`Health Future Map disponibile su http://127.0.0.1:${PORT}`);
  console.log("Le cartelle vengono create esclusivamente dentro:", ARCHIVIO);
});
